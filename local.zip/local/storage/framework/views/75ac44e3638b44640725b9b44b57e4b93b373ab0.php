<?php $__env->startSection('title'); ?>
  الصفحة الرئيسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> الصفحة الرئيسية
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
   
                    
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <a class="dashboard-stat dashboard-stat-light blue-soft" href="<?php echo e(url('users/all-users')); ?>">
        <div class="visual">
            <i class="fa fa-users"></i>
        </div>
        <div class="details">
            <div class="number">
             <?php echo e($admin_num); ?>

            </div>
            <div class="desc">
                عدد المستخدمين
            </div>
        </div>
        </a>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <a class="dashboard-stat dashboard-stat-light red-soft" href="<?php echo e(url('admin/member/view-all')); ?>">
        <div class="visual">
            <i class="fa fa-shopping-cart"></i>
        </div>
        <div class="details">
            <div class="number">
                  <?php echo e($order_num); ?>

            </div>
            <div class="desc">
                 عدد الطلبيات
            </div>
        </div>
        </a>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <a class="dashboard-stat dashboard-stat-light green-soft" href="<?php echo e(url('admin/course/view-all')); ?>">
        <div class="visual">
            <i class="fa fa-users"></i>
        </div>
        <div class="details">
            <div class="number">
               <?php echo e($emp_num); ?>

            </div>
            <div class="desc">
                عدد الموظفين
            </div>
        </div>
        </a>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <a class="dashboard-stat dashboard-stat-light purple-soft" href="<?php echo e(url('admin/team-work/view-all')); ?>">
        <div class="visual">
            <i class="fa fa-home"></i>
        </div>
        <div class="details">
            <div class="number">
             <?php echo e($store_num); ?>

            </div>
            <div class="desc">
                 عدد المخازن
            </div>
        </div>
        </a>
    </div>
</div> 
                
<div class="clearfix">
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>