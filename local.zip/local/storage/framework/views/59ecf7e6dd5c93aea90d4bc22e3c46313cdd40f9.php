<?php $__env->startSection('title'); ?>
  الصفحة الرئيسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> الصفحة الرئيسية
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="index.html">الصفحة الرئيسية</a>
    </li>
                    
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="row"></div>
                    <!-- END PAGE HEADER-->
                    <!-- BEGIN DASHBOARD STATS 1-->
                   
                    <div class="clearfix"></div>
                    <!-- END DASHBOARD STATS 1--> 
               
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>