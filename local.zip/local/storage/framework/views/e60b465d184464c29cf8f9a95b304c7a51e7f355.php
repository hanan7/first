<?php $__env->startSection("title"); ?>
العملاء
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
 <h1 class="page-title">العملاء</h1>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">العملاء</a>
  </li>
</ul>
<?php $__env->stopSection(); ?>
                              
<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('assets/admin/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
            <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
                <div class="portlet box green">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus"></i>اضافة قسم
                        </div>
                    </div>

                    <div  class="portlet-body form">
                            <form method="post" name="settingform"   id="settingform" class="horizontal-form">
                                <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <div class="form-body">
                   <h3 class="form-section">معلومات اساسية</h3> 
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold">اسم العميل <span style="color:red;">*</span></label>
                            <ul class="nav nav-tabs">
                                <li class="active ">
                                    <a href="#tab_1" data-toggle="tab" aria-expanded="true"> 
                                      <img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    </a>
                                </li>
                               <li>
                                   <a href="#tab_2" data-toggle="tab" aria-expanded="true"> 
                                        <img src="<?php echo e(asset('assets/admin/global/img/flags/gb.png')); ?>">
                                    </a>
                               </li>
                           </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade active in" id="tab_1">
                                    <div class=" input-icon right">       
                                      <input type="text" id="ar_name" name="ar_name" value="" class="form-control required" >
                                    </div>
                                  </div>
                                <div class="tab-pane fade" id="tab_2">
                                    <label class="control-label bold">اسم العميل</label>
                                    <div class=" input-icon right"> 
                                        <input type="text" id="en_name" name="en_name" value="" class="form-control " >
                                    </div>
                                </div>
                            </div>
                         </div>
                      </div>
                    </div>
                    
                                <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold">اسم الدكان</label>
                            <div class="input-icon right">
                              <input type="text" class="form-control" onblur="myfunctionname()" name="name" id="name">
                            </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold"> الايميل</label>
                            <div class="input-icon right">
                              <input type="email" onblur="myfunctionemail()" class="form-control"  name="email" id="email">
                            </div>
                          </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold"> رقم التليفون</label>
                            <div class="input-icon right">
                              <input type="text" class="form-control" onblur="myfunctionphone()" name="phone" id="phone">
                            </div>
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold">البلد</label>
                            <div class="input-icon right">
                              <input type="text" class="form-control" onblur="myfunctioncountry()" name="country" id="country">
                            </div>
                          </div>
                        </div>
                      </div>  
                            
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label bold">العنوان</label>
                            <div class="input-icon right">
                              <input type="text" class="form-control" onblur="myfunctionaddress()" name="address" id="address">
                            </div>
                        </div>
                      </div>
                    </div>
                    </div>            
                                    <div class="form-actions">
                                        <div class="col-md-12 text-center" >
                                            <button type="button" class="btn green btn_save">
                                                <i class="fa fa-check"></i> حفظ</button>
                                            <button type="button" class="btn default btn_save">
                                                <i class="fa fa-times"></i> الغاء</button> 
                                        </div>      
                                    </div>
                            </form>
                    </div>
                </div>
            </div>
    </div>
</div> 
                              
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
 
<script src="<?php echo e(asset('assets/admin/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/admin/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-level-script'); ?>
<script src="<?php echo e(asset('assets/admin/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript"></script>        
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>