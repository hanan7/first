<?php $__env->startSection("title"); ?>
رسائل الزوار
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
    rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />              
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">رسائل الزوار</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="<?php echo e(url('/admin')); ?>">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">رسائل الزوار</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
 
 <?php if(session()->has('sucess')): ?>
 <?php $a=[];
 $a = session()->pull('sucess');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
 <?php if(session()->has('danger')): ?>
 <?php $a=[];
 $a = session()->pull('danger');
 ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>

 
  	<div class="portlet box blue ">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> عرض رسائل الزوار</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
         
        </div>  

      
         <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th class="text-center"> رقم الرسالة </th>
                <th class="text-center"> اسم المرسل</th>
                <th class="text-center"> الايميل</th>
                <th class="text-center"> المحتوى</th>
                <th class="text-center">العمليات</th>
              </tr>
            </thead>
             
            <tbody>
            <?php foreach($msg as $msg): ?>
              <tr>
                   
                    <td class="text-center"> <?php echo e($msg->id); ?></td>
                    <td class="text-center"> <?php echo e($msg->name); ?> </td>
                    <td class="text-center"> <?php echo e($msg->email); ?> </td>
                    <td class="text-center"> <?php echo e($msg->content); ?> </td>
                  
                
                    <td class="text-center">
                    
                      <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                      <a href="#deletemodal" data-toggle="modal" class="btn btn-danger btndelet"  >
                          <li class="fa fa-trash">  مسح</li>
                      </a>
                      <?php endif; ?>
                    </td>
              </tr>
              <?php endforeach; ?> 
            </tbody>
          </table>
       
    </div> 
</div>

<!-- Modal -->
<div id="deletemodal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title bold">مسح عنصر</h4>
      </div>
      <div class="modal-body">
        <p>هل تريد تأكيد عملية المسح ؟</p>
      </div>
      <div class="modal-footer">
      <?php if(!empty($msg)): ?>
        <a href="<?php echo e(URL('msgs/'.'delete/'.$msg->id)); ?>" id="delete" class="btn btn red"><li class="fa fa-trash"></li> مسح</a>
      <?php endif; ?>
        <button type="button" class="btn btn dafault" data-dismiss="modal"><li class="fa fa-times"></li> الغاء</button>
    
      </div>
      </form>
    </div>

  </div>
</div
<?php $__env->stopSection(); ?>

<?php $__env->startSection("layoutscripts"); ?>
        ><script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("levelscripts"); ?>
 <script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript">
 	
 </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>