<?php $__env->startSection('content'); ?>    
    <div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ رحلة <?php echo e($trip->trip_name); ?> ـــــــ
                        <p>
                            <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('trip/alltrips')); ?>">
                                    /
                                    رحلات
                                </a>
                            </li>
                            / <?php echo e($trip->trip_name); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="only-trip-content">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-8 col-sm-12">
                        <div id="pro-carousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner" role="listbox">
                            <?php foreach($trip->photos as $ph): ?>
                                <div class="item active zoom">
                                    <img class="img-responsive"  src="<?php echo e(url('uploads/' . $ph->images . "")); ?>">
                                </div>
                             
                                <ol class="carousel-indicators">
                                
                                    <li data-target="#pro-carousel" data-slide-to="0">
                                        <img class="img-responsive" src="<?php echo e(url('uploads/' . $ph->images . "")); ?>">
                                    </li>
                                </ol>
                            <?php endforeach; ?>     
                            </div>
                        </div>
                        <div class="trip-information">
                            <ul id="myTab" class="nav nav-tabs nav_tabs">
                                <li class="active"><a href="#trip-one" data-toggle="tab">عن الرحلة</a></li>
                                <li><a href="#trip-two" data-toggle="tab">برنامج الرحلة</a></li>
                               
                            </ul>
                            <div id="myTabContent" class="tab-content">
                                <div class="tab-pane fade in active " id="trip-one">
                                    <p>
                                        <?php echo e($trip->long_desc); ?>

                                    </p>
                                    
                                </div>
                                <div class="tab-pane fade" id="trip-two">
                                    <div class="day-des">
                                        <h4>
                                                اليوم الأول
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day1); ?>

                                        </p>
                                        <h4>
                                                اليوم التانى
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day2); ?>

                                        </p>
                                        <h4>
                                                اليوم التالت
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day3); ?>

                                        </p>
                                        <h4>
                                                اليوم الرابع
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day4); ?>

                                        </p>
                                        <h4>
                                                اليوم الخامس
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day5); ?>

                                        </p>
                                        <h4>
                                                اليوم السادس
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day6); ?>

                                        </p>
                                        <h4>
                                                اليوم السابع
                                        </h4>
                                        <p>
                                           <?php echo e($trip->day7); ?>

                                        </p>
                                        
                                    </div>
                                   

                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-12">
                        <div class="related">
                            <div class="related-title">
                                <span class="fa fa-thumb-tack"></span> معلومات عن الرحلة
                            </div>
                            <div class="main-info">
                                <p>
                                    <span class="fa fa-home"></span> إسم الرحلة : رحلة <?php echo e($trip->trip_name); ?>

                                </p>
                                <p>
                                    <span class="fa fa-clock-o"></span> مدة الرحلة : <?php echo e($trip->days); ?> ايام
                                </p>
                                <p>
                                    <span class="fa fa-usd"></span> سعر الرحلة : <?php echo e($trip->price); ?> $
                                </p>
                                <p>
                                    <span class="fa fa-calendar"></span> ميعاد الرحلة : <?php echo e($trip->created_at); ?>

                                </p>
                                <a href="<?php echo e(url('trip/booking')); ?>">
                                    <button class="btn btn-default">إحجز الأن</button>
                                </a>
                            </div>
                        </div>
                        <div class="related">
                            <div class="related-title">
                                <span class="fa fa-thumb-tack"></span> رحلات  متعلقة
                            </div>
                        <?php foreach($same as $same): ?>    
                            <div class="tour-small">
                                <div class="tour-small-img">
                                    <img src="<?php echo e(url('uploads/trips/' . $same->image . '')); ?>">
                                </div>
                                <div class="tour-small-descrip">
                                    <a href="only-trip.html">
                                        <p>رحلة <?php echo e($same->trip_name); ?></p>
                                    </a>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star-o"></span>
                                    <a href="<?php echo e(url('trip/booking')); ?>">
                                        <button class="btn btn-default">إحجز الأن</button>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>    

                        </div>
                        <div class="serv">
                            <span class="flaticon-24-hours-support"></span>
                            <h1>
                                 <i>24</i>
                                ساعة خدمة عملاء
                            </h1>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>