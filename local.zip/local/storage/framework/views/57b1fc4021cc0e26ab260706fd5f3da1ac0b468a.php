<?php $__env->startSection('title'); ?>
الاقسام
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> الاقسام
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
   	 	<i class="icon-home"></i>
    	<a href="index.html">الصفحة الرئيسية</a>
    	<i class="fa fa-angle-left"></i>
    </li>
    <li>
       	<a href="#">الاقسام</a>
    </li>                   
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
  <?php endif; ?>


<div class="portlet box green ">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> عرض الاقسام</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                <a  href="<?php echo e(url('categories/add')); ?>" class="btn btn green" ><i class="fa fa-plus"></i>  اضافة قسم جديد
                </a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="btn-group pull-right">
                  <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">الادوات
                    <i class="fa fa-angle-down"></i>
                  </button>
                  <ul class="dropdown-menu pull-right">
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-print"></i> طباعه  </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-file-pdf-o"></i> حفظ ك  PDF </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-file-excel-o"></i> تصدير الى  Excel </a>
                    </li>
                  </ul>
              </div>
            </div>
          </div>
        </div>  

        <div class="well table-toolbar">
          	<form id="search_form" name="searchform" method="get"> 
                <div class="row">  
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label class="control-label bold">اسم القسم</label>
                            <select name="cats" type="search" id="span_small" aria-hidden="true" class=" form-control ">
                               <!-- $categories  identified in app service provider -->
                            <?php foreach($categories as $maincat): ?>
                          <?php if(!empty($maincat->cat_trans('ar'))): ?>
                          <option value="<?php echo e($maincat->id); ?>"><?php echo e($maincat->cat_trans('ar')->name); ?></option>
                             <?php if(!$maincat->subcat->isEmpty()): ?>
                             <?php foreach($maincat->subcat as $sub1): ?>
                                            <?php if(!empty($sub1->cat_trans('ar'))): ?>
                          <option value="<?php echo e($sub1->id); ?>"><?php echo e($sub1->cat_trans('ar')->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                            
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php endforeach; ?>
                                </option>
                            </select>
                        </div>
                    </div> 
                </div>
              
                <div class="col-md-6 col-sm-6 text-center">
                    <button type="button" name="filterBtn" id="filterBtn" class="btn green">
                        <li class="fa fa-search"></li> بحث
                    </button>
                </div>
              </form>         
        </div>
        
        <div id="reloaddiv">
         <div id="searchlist"></div>
         <?php echo $__env->make('admin.pages.categories.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div> 
</div> 
<script type="text/javascript">
    
    function formFilter(){
    
    var data = $("#searchform").serialize();
    
    $.ajax({
        url: '<?php echo e(url("categories/search")); ?>' , 
        type: "GET",
        data: data,
        beforeSend: function(){
            $('#filterBtn').button('loading');
        },
        success: function(result){              
            $("#searchlist").html(result);
             $('#sample_1').dataTable();
         
             $('#filterBtn').button('reset');
             $('.tooltips').tooltip();
        },
        error: function(error){
            
        }
    });
  };
    
  $("#filterBtn").click(formFilter);
  $("#filterBtn").trigger("click");
</script>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>