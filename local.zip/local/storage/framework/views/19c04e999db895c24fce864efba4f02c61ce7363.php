<?php $__env->startSection('content'); ?>
<div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ عن المضيــف ـــــــ
                        <p>
                            <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            | عن الشركة
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="about-content">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="logo">
                            <img src="<?php echo e(URL('uploads/' . $sections->logo . "")); ?>">
                        </div>
                        <div class="steps">
                            <h2>
                            إختار رحلتك الأن مع المضيف
                        </h2>
                            <h3>
                            هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                        </h3>
                            <p>
                                <span>1</span> إختار رحلتك المفضلة
                            </p>
                            <p>
                                <span>2</span> حجز الرحلة وملئ البيانات
                            </p>
                            <p>
                                <span>3</span> إستلام التذكرة والتمتع بالرحلة
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-24-hours-support"></span>
                            <h1>
                                 <i>24</i>
                                ساعة خدمة عملاء
                            </h1>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-map-with-position-marker"></span>
                            <h1>
                                 <i>+ <?php echo e($sections->trips_num); ?></i>
                                رحلة سياحية
                            </h1>
                            <p>
                                <?php echo e($sections->trips_desc); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-man-travelling"></span>
                            <h1>
                                 <i>+ <?php echo e($sections->agents_num); ?></i>
                              عميل
                            </h1> 
                            <p>
                               <?php echo e($sections->agents_desc); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="features">
            <div class="container-fluid over">
                <div class="row text-center">
                    <img src="<?php echo e(URL('assets/front/images/logo-h.png')); ?>">
                    <h4> تمتع معنا بخدمة متميزة وأسعار مناسبة</h4>
                    <i class="fa fa-star-o"></i>
                    <i class="fa fa-star-o"></i>
                    <i class="fa fa-star-o"></i>
                    <i class="fa fa-star-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
            </div>
        </div>
        <div class="testmonia">
            <div class="container">
                <div class="row text-center">
                    <h2>
                        ماذا يقول الناس عن المضيف
                    </h2>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-4.jpg')); ?>">
                            <h3>
                                محمد صادق
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-3.jpg')); ?>">
                            <h3>
                              هشام جمال
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-2.jpg')); ?>">
                            <h3>
                               محمد يحيى
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-1.jpg')); ?>">
                            <h3>
                               حنان أدم
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-1.jpg')); ?>">
                            <h3>
                               علا محمد
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="opinion">
                            <img src="<?php echo e(URL('assets/front/images/team-4.jpg')); ?>">
                            <h3>
                                محمد صادق
                            </h3>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>