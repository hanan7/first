  <div class="page-sidebar-wrapper">
                <div class="page-sidebar navbar-collapse collapse">
                    <ul class="page-sidebar-menu  page-header-fixed page-sidebar-menu-hover-submenu  page-sidebar-menu-compact" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                        <li class="nav-item start">
                            <a href="<?php echo e(URL('admin')); ?>" class="nav-link ">
                                <i class="icon-home"></i>
                                <span class="title">الرئيسية</span>
                               
                                <span class="arrow"></span>
                            </a>
                            
                        </li>
                        <li class="nav-item  ">
                            <a href="" class="nav-link">
                               <i class="icon-settings"></i>
                                <span class="title">الضبط</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item  ">
                                    <a href="<?php echo e(URL('settings/general-settings')); ?>" class="nav-link ">
                                     <i class="icon-settings"></i>
                                        <span class="title">الاعدادات العامة</span>
                                    </a>
                                </li>
                                <li class="nav-item  ">
                                    <a href="<?php echo e(URL('attributes/index')); ?>" class="nav-link ">
                                     <i class="icon-puzzle"></i>
                                        <span class="title">المتغيرات</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('categories/all-categories')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">الاقسام</span>
                            </a>
                        </li>
                        
                        <li class="nav-item  ">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-bulb"></i>
                                <span class="title">الدكاكين</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item  ">
                                    <a href="<?php echo e(URL('dakaken/index')); ?>" class="nav-link ">
                                        <span class="title">الدكاكين</span>
                                    </a>
                                </li>
                                <li class="nav-item  ">
                                    <a href="<?php echo e(URL('products/index')); ?>" class="nav-link ">
                                        <span class="title">المنتجات</span>
                                    </a>
                                </li>
                            
                            </ul>
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('customers/index')); ?>" class="nav-link nav-toggle">
                                <i class="icon-briefcase"></i>
                                <span class="title">العملاء</span>
                                <span class="arrow"></span>
                            </a>
                            
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('orders/index')); ?>" class="nav-link nav-toggle">
                                <i class="icon-briefcase"></i>
                                <span class="title">المبيعات</span>
                                <span class="arrow"></span>
                            </a>
                            
                        </li>
                            <li class="nav-item  ">
                            <a href="<?php echo e(URL('souq/index')); ?>" class="nav-link nav-toggle">
                                <i class="icon-briefcase"></i>
                                <span class="title">سوق الجمعة</span>
                                <span class="arrow"></span>
                            </a>
                           
                        </li>
                        
                         <li class="nav-item  ">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">التقارير</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item ">
                                    <a href="" class="nav-link  nav-toggle">
                                        <span class="title ">تقارير المبيعات</span>
                                    </a>
                                    <ul class="sub-menu">
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vallsales')); ?>" class="nav-link ">
                                         <span class="title "> التقرير الاجمالى</span>
                                         </a>
                                        </li>
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vsales')); ?>" class="nav-link ">
                                         <span class="title ">التقرير التفصيلى</span>
                                         </a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="nav-item  ">
                                    <a href="" class="nav-link nav-toggle">
                                        <span class="title"> تقارير المنتجات</span>
                                    </a>
                                    <ul class="sub-menu " >
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vproduct')); ?>" class="nav-link ">
                                         <span class="title ">نسب المشاهدة</span>
                                         </a>
                                        </li>
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vallproduct')); ?>" class="nav-link ">
                                         <span class="title ">المنتجات المباعة</span>
                                         </a>
                                        </li>
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vtakenproduct')); ?>" class="nav-link ">
                                         <span class="title ">المنتجات المحجوزة</span>
                                         </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item  ">
                                    <a href="" class="nav-link  nav-toggle">
                                        <span class="title"> تقارير العملاء</span>
                                    </a>
                                    <ul class="sub-menu">
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vallagents')); ?>" class="nav-link ">
                                         <span class="title ">اجمالى العملاء</span>
                                         </a>
                                        </li>
                                        <li class="nav-item ">
                                         <a href="<?php echo e(URL('reports/vagent')); ?>" class="nav-link ">
                                         <span class="title ">التقرير التفصيلى</span>
                                         </a>
                                        </li>
                                    </ul>
                                    
                                </li>
                                <li class="nav-item">
                                  <a href="<?php echo e(URL('reports/vdiscount')); ?>" class="nav-link nav-toggle">
                                   <span class="title">تقارير كوبونات الخصم</span>
                                 </a>
                                </li>
                                
                              
                            </ul>
                        </li>
                  
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
            </div>