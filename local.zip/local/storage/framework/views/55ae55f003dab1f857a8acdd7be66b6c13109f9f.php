<?php $__env->startSection("title"); ?>
حجز طائرة
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
    rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />              
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">حجز طائرة</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">حجز طائرة</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
 <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('success')); ?> </p>
    
    </div>
 <?php endif; ?>
  <?php if(session()->has('danger')): ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('danger')); ?> </p>
    
    </div>
  <?php endif; ?> 

    <div class="portlet box green ">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> عرض حجوزات الطائرة</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
          
        </div>  

      
         <table class="table table-splaned table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th>
                    <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" /> 
        </th>
                <th class="text-center"> رقم الحجز </th>
                <th class="text-center"> اسم العميل</th>
                <th class="text-center"> التليفون</th>
                <th class="text-center"> الايميل</th>
                <th class="text-center"> التاريخ من: </th>
                <th class="text-center"> الى :</th>
                <th class="text-center">العمليات</th>
              </tr>
            </thead>
             
            <tbody>
            <?php foreach($plans as $plan): ?>
              <tr>
                    <td>
                      <input type="checkbox" class="checkboxes" value="1" /> 
                    </td>
                    <td class="text-center"> <?php echo e($plan->id); ?></td>
                    <td class="text-center"> <?php echo e($plan->agent->name); ?> </td>
                    <td class="text-center"> <?php echo e($plan->agent->phone); ?> </td>
                    <td class="text-center"> <?php echo e($plan->agent->email); ?> </td>
                    <td class="text-center"> <?php echo e($plan->start_date); ?></td>
                    <td class="text-center"> <?php echo e($plan->end_date); ?></td>
                    <td class="text-center">
                     <a href="<?php echo e(URL('reserve/'.'show-plans/'.$plan->id)); ?>" data-toggle="tooltip" title class="btn btn blue" data-original title="عرض">
                          <li class="fa fa-eye"> عرض التفاصيل</li>
                      </a>
                      <a href="#deletemodal" data-toggle="modal" class="btn btn-danger btndelet"  >
                          <li class="fa fa-trash">  مسح</li>
                      </a>
                    </td>
              </tr>
              <?php endforeach; ?> 
            </tbody>
          </table>
       
    </div> 
</div>

<!-- Modal -->
<div id="deletemodal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">مسح عنصر</h4>
      </div>
      <div class="modal-body">
        <p>هل تريد تأكيد عملية المسح ؟</p>
      </div>
      <div class="modal-footer">

        <a href="<?php echo e(URL('reserve/'.'delete-plan/'.$plan->id)); ?>" id="delete" class="btn btn red"><li class="fa fa-trash"></li> مسح</a>
     
        <button type="button" class="btn btn dafault" data-dismiss="modal"><li class="fa fa-times"></li> الغاء</button>
    
      </div>
      </form>
    </div>

  </div>
</div
<?php $__env->stopSection(); ?>

<?php $__env->startSection("layoutscripts"); ?>
        <script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("levelscripts"); ?>
 <script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript">
  
 </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>