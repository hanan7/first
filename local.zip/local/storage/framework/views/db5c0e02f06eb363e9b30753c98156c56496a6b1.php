<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(URL('assets/front/images/fav-icon.png')); ?>" rel='icon' type='image/x-icon' />
    <!-- include css files -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/bootstrap-rtl.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/style.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-rtl.min.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <title>المضيف</title>
</head>

<body>
<!-- Start Header -->
<?php echo $__env->make('front.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- End Header -->
<div class="clear"></div>
<!-- Start Wrap -->
    <?php echo $__env->yieldContent('content'); ?>
<!-- End Wrap -->
<div class="clear"></div>

<!-- Start Footer -->
<?php echo $__env->make('front.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- End Footer -->
    <!-- includ js files -->
    <script src="<?php echo e(URL('assets/front/js/jquery.js')); ?>"></script>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <script src="<?php echo e(URL('assets/front/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/custom.js')); ?>"></script>

 
</body>

</html>     