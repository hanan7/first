<?php $__env->startSection('content'); ?>

 <section class="our-services text-center" id="our-services">
        <div class="servic">
            <div class="container">
                <h2 class="h1">المنتجات</h2>
                <div class="row">
                  <?php foreach($products as $pro): ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-offset="300">
                        <div class="service-box">
                            <h3 class="text-primary"><?php echo e($pro->name); ?></h3>
                            <p class="first-child center-block"><?php echo e($pro->s_price); ?></p>
                            <img src="<?php echo e(url('uploads/products/'.$pro->image)); ?>" alt="pic1" />
                            <p class="para"><?php echo e($pro->desc); ?></p>
                           
                        </div>
                    </div>
                  <?php endforeach; ?>
                   
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>