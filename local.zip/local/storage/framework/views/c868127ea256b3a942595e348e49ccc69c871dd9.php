<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>خدمتنا</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2031 Green Age
http://www.tooplate.com/view/2031-green-age
-->
<link href="<?php echo e(URL('assets/front/css/tooplate_style.css')); ?>" rel="stylesheet" type="text/css" />

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>

<link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/jquery.lightbox-0.5.css')); ?>" />    
    
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="<?php echo e(URL('assets/front/js/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL('assets/front/js/jquery.lightbox-0.5.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/jquery.lightbox-0.5.css')); ?>" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('.lightbox').lightBox();
});
</script>

</head>
<body class="subpage">

<div id="tooplate_wrapper">
    <div id="tooplate_header" style="background-color:#060">
        
      <a href="#"> <img src="<?php echo e(URL('assets/front/images/tooplate_logo2.jpg')); ?>"  width="300" height="90" style="margin-top:-10px; margin-left:300px;"/></a>
        <div class="cleaner"></div>
    </div>
    
     <div id="tooplate_menu">
        <ul>
            <li><a href="index.html" >الرئيسيه</a></li>
            <li><a href="gallery.html" class="current">خدمتنا</a></li>
            <li><a href="news.html">تسجيل دخول</a></li>
            <li class="last"><a href="contact.html">اتصل بنا</a></li>
        </ul>       
        
        
        
        <div class="cleaner"></div>
    </div> <!-- end of tooplate_menu -->
    
    <div id="tooplate_middle_subpage">
        <h2>خدمتنا</h2>
        <p>توفر لكم خدمتنا افضل المميزات والعروض الموجوده فى السوق المحليه والعالميه وتسهل على العملاء التعامل مع الويب سايت
    </div>
        
    <div id="tooplate_main">
        <div class="col_w960">
            
            <div id="gallery">
                
               
                
                
                
                
                
                
                
                
            </div>
            <div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
        
</div> <!-- end of wrapper -->

<div id="tooplate_cr_wrapper">
    <div id="tooplate_cr">
        
      <a href="#">  Copyright © 2016</a><br /><a href="#">جميع الحقوق محفوظه:</a>   <a href="">-شركه ذكاء للبرمجيات</a>
        
    </div> <!-- end of footer wrapper -->
</div> <!-- end of footer -->
</body>
</html>