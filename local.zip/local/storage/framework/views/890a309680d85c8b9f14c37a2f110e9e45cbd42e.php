<?php $__env->startSection("title"); ?>
الموظفين
<?php $__env->stopSection(); ?>
<?php $__env->startSection("page-style"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
              rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">الموظفين</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">الموظفين</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
<?php if(session()->has('sucess')): ?>
 <?php $a=[];
 $a = session()->pull('sucess');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
  <?php if(session()->has('danger')): ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('danger')); ?> </p>
    
    </div>
  <?php endif; ?> 
  <div class="row">
    <div class="col-md-12">
      <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
        <div class="portlet box green">
                    <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-plus"></i>
                                    تعديل الموظفين
                                </div>
                            </div>

                    <div  class="portlet-body form">
                       <form method="post" name="settingform" action="<?php echo e(URL('employees/edit/'.$old->id)); ?>"  id="settingform" class="horizontal-form"  files="true" enctype="multipart/form-data">
                           <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                           
                        <div class="form-body">
                              <h3 class="form-section">تعديل موظف</h3>
                            
                               <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">كود الموظف</label>
                                        <input type="number" id="code" name="code" class="form-control" 
                                        value="<?php echo e($old->code); ?>">
                                      </div>
                                  </div>
                                
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">اسم الموظف</label>
                                        <input type="text" id="name" name="name" class="form-control" 
                                        value="<?php echo e($old->name); ?>">
                                      </div>
                                    </div>
                                </div>  
                                
                                    
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">العنوان</label>
                                        <input type="text" id="address" name="address"  class="form-control" 
                                        value="<?php echo e($old->address); ?>">
                                      </div>
                                  </div>
                                
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">التليفون</label>
                                        <input type="text" id="phone" name="phone"  class="form-control" value="<?php echo e($old->phone); ?>">
                                      </div>
                                  </div>
                                </div>

                                 <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">الوظيفة</label>
                                        <input type="" id="job" name="job" class="form-control"
                                        value="<?php echo e($old->job); ?>">
                                      </div>
                                    </div>

                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">الراتب</label>
                                        <input type="number" id="salary" name="salary" class="form-control" value="<?php echo e($old->salary); ?>">
                                      </div>
                                    </div> 
                                </div>  

                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">تاريخ التعاقد</label>
                                        <input type="date" id="contract_date" name="contract_date" 
                                         class="form-control" value="<?php echo e($old->contract_date); ?>">
                                      </div>
                                  </div>
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">تاريخ الانتهاء</label>
                                        <input type="date" id="end_date" name="end_date" 
                                         class="form-control" value="<?php echo e($old->end_date); ?>">
                                      </div>
                                  </div>
                                </div> 
                        </div>
                          <div class="form-actions">
                            <div class="col-md-12 text-center" >
                              <button type="submit"  name="submit" class="btn green btn_save">
                              <i class="fa fa-pencil"></i> تعديل</button>
                             <a href="<?php echo e(url('employees/all-employees')); ?>" type="button" class="btn default btn_save">
                              <i class="fa fa-times"></i> الغاء</a> 
                            </div>      
                          </div>
                       </form>
                    </div>
                 </div>
                    
                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>