<?php $__env->startSection("title"); ?>
المنتجات
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/style.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
<h3 class="page-title">المنتجات</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="<?php echo e(url('/admin')); ?>">الصفحة الرئيسية</a>
        <i class="fa fa-angle-left"></i>
    </li>
    <li>
        <a href="#">المنتجات</a>


    </li>

</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(isset($errors)&&count($errors)>0): ?>
<div class="alert alert-danger">
    <ul>
        <?php foreach($errors->all() as $error): ?>
        <li>
            <?php echo e($error); ?>

        </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
<?php
$a = [];
$a = session()->pull('success');
?>
<div class="alert alert-success alert-dismissable">
    <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
    <?php echo e($a[0]); ?>


</div>
<?php endif; ?>
<?php if(session()->has('danger')): ?>
<?php
$a = [];
$a = session()->pull('danger');
?>
<div class="alert alert-warning alert-dismissable">
    <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
    <?php echo e($a[0]); ?>


</div>
<?php endif; ?>

<div class="portlet box blue ">
    <div class="portlet-title">
        <div class="caption">
            <i class="fa fa-eye"></i> عرض المنتجات</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
            <div class="row">
                <div class="col-md-6">
                    <div class="btn-group">
                        <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                        <a href="#addmodal" class="btn btn blue"  data-toggle="modal"><i class="fa fa-plus"></i>  اضافة منتج
                        </a>
                        <a href="#cat-modal" class="btn btn green"  data-toggle="modal"><i class="fa fa-plus"></i>  اضافة صنف
                        </a>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>  


        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
                <tr>
                    <th class="text-center"> كود المنتج </th>
                    <th class="text-center"> اسم المنتج</th>
                    <th class="text-center"> نقاط مبيعات</th>
                    <th class="text-center"> سعر البيع </th>
                    <th class="text-center"> الصورة</th>
                    <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                    <th class="text-center"> الكمية</th>
                    <th class="text-center"> سعر الشراء </th>
                    <th class="text-center"> الشركة الموردة</th>
                    <th class="text-center"> المخزن</th>
                    <th class="text-center">العمليات</th>
                    <?php endif; ?>
                </tr>
            </thead>

            <tbody>
                <?php foreach($products as $pro): ?>
                <tr>

                    <td class="text-center"> <?php echo e($pro->code); ?></td>
                    <td class="text-center"> <?php echo e($pro->name); ?> </td>
                    <td class="text-center"> <?php echo e($pro->points); ?> </td>
                    <td class="text-center"> <?php echo e($pro->s_price); ?> </td>
                    <td class="text-center"> <img src="<?php echo e(url('uploads/products/'.$pro->image)); ?>" style="width:100px; height:100px; "/></td>
                    <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                    <td class="text-center"> <?php echo e($pro->quantity); ?> </td>
                    <td class="text-center"> <?php echo e($pro->b_price); ?> </td>
                    <td class="text-center"> <?php echo e($pro->company); ?></td>
                    <td class="text-center"> <?php echo e($pro->store); ?></td>
                    <td class="text-center">
                        <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                        <a href="<?php echo e(URL('products/'.'edit/'.$pro->id)); ?>"  class="btn green btnedit" data-original="">
                            <li class="fa fa-pencil"> تعديل</li>
                        </a>
                        <a data-url="<?php echo e(URL('products/'.'delete/'.$pro->id)); ?>" class="btn btn-danger btndelet"  >
                          <li class="fa fa-trash">  مسح</li>
                      </a>
                        <button type="button" class="btn-details btn btn-dafault" data-product-id="<?php echo e($pro->id); ?>" >تفاصيل</button>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>  
                </tr>
                <?php endforeach; ?> 
            </tbody>
        </table>

    </div> 
</div>

<!--Model's for processing-->
<?php echo $__env->make('admin.pages.products.add-product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.pages.products.add-category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.pages.products.product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.pages.products.product-delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!--End of modal for processing-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection("layoutscripts"); ?>
<script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<script id="product-details-template">
    <?php echo $__env->make('admin.templates.product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</script>
<script id="category-template">
    <?php echo $__env->make('admin.templates.category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("levelscripts"); ?>
<script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript">

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>