 <div class="subscrib">
        <div class="container-fluid">
            <div class="row">
                <div class="det">
                    <span class="fa fa-envelope-o"></span>
                    <p>إشترك لتصلك أخر الاخبار</p>
                </div>
                <div class="sub-form">
                    <form method="get" action="">
                        <input type="email" placeholder="إكتب بريدك الإلكترونـى هنا" class="form-control">
                        <button class="btn btn-default" type="submit">إشتــراك</button>
                    </form>
                </div>
                <div class="sub-scoil">
                    <a href="">
                        <span class="fa fa-facebook s"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-twitter"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-google-plus"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-linkedin"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-youtube"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-instagram"></span>
                    </a>
                    <a href="">
                        <span class="fa fa-whatsapp"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>
    <footer>
        <div class="container-fluid">
            <div class="row">
                <div class="about">
                    <div class="logo">
                        <img src="<?php echo e(URL('assets/front/images/logo.png')); ?>">
                    </div>
                    <div class="det">
                        <p>
                            يُعد موقع دكان دوت كوم مركزًا للتسوق اون لاين الأفضل والأسهل من حيث الاستخدام في الامارات، حيث يلبي الموقع جميع احتياجات العملاء بأفضل الطرق الممكنة.
                        </p>
                    </div>
                </div>
                <div class="con">
                    <div class="client">
                        <div class="sec-tit">
                            <i class="fa fa-group"></i> شركاءنا الاستراتيجيين
                        </div>
                        <div id="client-slid" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner" role="listbox">
                                <div class="item active">
                                    <img src="images/1.jpg">
                                    <img src="images/2.jpg">
                                    <img src="images/3.jpg">
                                </div>
                                <div class="item">
                                    <img src="images/4.jpg">
                                    <img src="images/5.jpg">
                                    <img src="images/1.jpg">
                                </div>
                                <div class="item">
                                    <img src="<?php echo e(URL('assets/front/images/2.jpg')); ?>">
                                    <img src="<?php echo e(URL('assets/front/images/3.jpg')); ?>">
                                    <img src="images/4.jpg">

                                </div>
                            </div>
                            <a class="left carousel-control" href="#client-slid" role="button" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#client-slid" role="button" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>

                    <div class="hot-link">
                        <div class="sec-tit">
                            <i class="fa fa-bookmark"></i> روايط سريعة
                        </div>
                        <ul>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> الرئيسية
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> عن الشركة
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> سوق الجمعة
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> خريطة الموقع
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> الأنشطة
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> تواصل معنا
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> المفضلة
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <i class="fa fa-caret-left"></i> كتالوجات
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="contact">
                    <div class="contact-det">
                        <div class="sec-tit">
                            <i class="fa fa-envelope-o"></i> تواصل معنا
                        </div>
                        <p>
                            <span class="fa fa-map-marker"></span> إعمار بوليفارد، بوسط المدينة - دبي
                        </p>
                        <p>
                            <span class="fa fa-phone"></span> 800-599-65-80
                        </p>
                        <p>
                            <span class="fa fa-mobile fa-lg"></span> 800-599-65-80
                        </p>
                        <p>
                            <span class="fa fa-envelope-o"></span> info@docaan.com
                        </p>
                    </div>
                    <div class="pay">
                        <div class="sec-tit">
                            <span class="fa fa-usd"></span> طرق الدفع
                        </div>
                        <img src="<?php echo e(URL('assets/front/images/payment.png')); ?>">
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <section class="copy-right">
        <div class="container-fluid">
            <div class="row text-center">
                <p>
                    جميع الحقوق محفوظة@ دكــــان 2016
                </p>
            </div>

        </div>
    </section>