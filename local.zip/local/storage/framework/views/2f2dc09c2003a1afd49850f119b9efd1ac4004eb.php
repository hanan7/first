<?php $__env->startSection('content'); ?>
<div id="tooplate_wrapper">

        <div id='hislider1' style=" width:960px;  height:300px; margin: 0 auto;">
          
        </div>
</div>       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>