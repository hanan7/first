<?php $__env->startSection("title"); ?>
الاعدادات العامة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/profile/css/style.css')); ?>">
    <link rel='stylesheet' href="<?php echo e(asset('assets/admin/profile/css/bootstrap.min.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('assets/admin/profile/css/bootstrap-rtl.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('assets/admin/profile/css/font-awesome.min.css')); ?>"/>
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:400,700,300'/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">الاعدادات العامة</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">الاعدادات العامة</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                 
<?php $__env->startSection('content'); ?>
   

    <section class="profile">

            <div class="card ">
                <div class="card-header text-center">
                    <img class="img-circle" src="<?php echo e(asset('assets/admin/profile/images/team1.jpg')); ?>" alt="User Profile">
                    <h3>الأسم</h3> 
                    <p>هذا النص نص تجريبى ويمكن استبداله بنص ااخر لوصف هذا الجزء هذا النص نص تجريبى ويمكن استبداله بنص ااخر لوصف هذا الجزء</p>
                    <a href="#"><i class="fa fa-google-plus fa-2x"></i></a> 
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="#"><i class="fa fa-twitter fa-2x"></i></a> 
                </div>
                <div class="data">
                    <ul class="list-unstyled">
                        <li class="first"> أسم المستخدم </li>
                        <li>الإيميل</li>
                        <li>العنوان</li>
                        <li>التليفون</li>
                        <li>معلومات إضافية</li>
                    </ul>
                </div>
            </div>
 
    </section>
    <?php $__env->startSection('layoutscripts'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="<?php echo e(asset('assets/admin/profile/js/jquery-1.12.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/admin/profile/js/animation.js')); ?>"></script> 
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>