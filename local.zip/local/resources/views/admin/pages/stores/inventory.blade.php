@extends("admin/master")

@section("title")
المخازن
@endsection
@section("styles")
<link href="{{asset('assets/admin/global/plugins/datatables/datatables.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')}}" 
    rel="stylesheet" type="text/css" />
<link href="{{asset('assets/admin/global/plugins/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />              
@endsection
@section("content-title")
 <h3 class="page-title">المخازن</h3>  
@endsection

@section("content-navigat")
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">المخازن</a>


 </li>
                         
</ul>
@endsection
                
@section('content')

 @if(isset($errors)&&count($errors)>0)
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                <li>
                    {{$error}}
                </li>
                @endforeach
            </ul>
        </div>
 @endif
 @if(session()->has('success'))
 <?php $a=[];
 $a = session()->pull('success');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     {{$a[0]}}
    
    </div>
 @endif
 @if(session()->has('danger'))
 <?php $a=[];
 $a = session()->pull('danger');
 ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     {{$a[0]}}
    
    </div>
 @endif
  	<div class="portlet box blue">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> جرد</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                
              </div>
            </div>
           
          </div>
        </div>  

       <form method="post" name="productform" action="{{url('/stores/inventory')}}" class=" horizontal-form">
        <input type="hidden"  name="_token" value="{{ csrf_token() }}">
         <input type="hidden"  name="store_id" 
                         class="form-control"
                        value="{{$store_id}}" >
          @if(count($storeGoods)>0) 
                       
         <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th class="text-center"> اسم المنتج  </th>
                <th class="text-center"> الكمية الموجودة</th>
                <th class="text-center"> الكمية اثناء الجرد</th>
                
               
                
              </tr>
            </thead>
             
            <tbody>

          @foreach($storeGoods as $str)
              <tr>
                   
                    <td class="text-center"> {{ $str->name }} </td>
                    <td class="text-center"> {{ $str->quantity }} </td>
                   
                     <td class="text-center"> 
                        <div class="form-group">
                        
                        <input type="text" id="quantity" name="quantity[{{ $str->id }}]"  
                        class="form-control"
                        value="" >

                        <input type="hidden"  name="oldQuantity[{{ $str->id }}]" 
                         class="form-control"
                        value="{{$str}}" >

                        
                       
                        </div>
                     </td>
              </tr>
          @endforeach 
         

            </tbody>

          </table>
            <div class="text-right">
                              
                              <button type="submit"  name="submit" class="btn green btn_save">
                              <i class="fa fa-pencil"></i> تسوية</button>
                              
                              <a href="{{url('stores/all-stores')}}" type="button" class="btn default btn_save">
                              <i class="fa fa-times"></i> الغاء</a> 
                            </div>
                          </form>
      @else
    <div class="alert alert-info"> لا يوجد بضائع بهذا المخزن</div>
      @endif

       
    </div>
  
</div>
   @include('admin.pages.stores.addstore') 
<!-- Modal -->

@endsection

@section("layoutscripts")
        ><script src="{{asset('assets/admin/global/scripts/datatable.js')}}" type="text/javascript"></script>
        <script src="{{asset('assets/admin/global/plugins/datatables/datatables.min.js')}}" type="text/javascript"></script>
        <script src="{{asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')}}" type="text/javascript"></script>


@endsection

@section("levelscripts")
 <script src="{{asset('assets/admin/pages/scripts/table-datatables-managed.min.js')}}" type="text/javascript">
 	
 </script>
@endsection

