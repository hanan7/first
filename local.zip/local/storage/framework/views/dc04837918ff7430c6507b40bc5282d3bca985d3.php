<?php $__env->startSection("page-title"); ?>
المبيعات
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
 <h1 class="page-title">المبيعات</h1>  
<?php $__env->stopSection(); ?>  

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">المبيعات</a>
     <i class="fa fa-angle-left"></i> 
 </li>
 <li>
   <a href="#">كل المبيعات</a>
  
 </li>                        
</ul>
<?php $__env->stopSection(); ?>
                    
<?php $__env->startSection('page-style'); ?>

<link href="<?php echo e(asset('assets/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
<!-- BEGIN CONTAINER -->
     
            <!-- BEGIN CONTENT -->
     
                               <?php if(Session::has('m')): ?>
                               
                                    <div class="container msgerror ">
                                      <?php $a=[]; $a=session()->pull('m'); ?>
                                      <div class="alert alert-<?php echo e($a[0]); ?>"><?php echo e($a[1]); ?></div>
                                    </div>

                                     <?php endif; ?>   
                                    
<div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                
                                
                          <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-eye"></i>عرض المبيعات </div>
                                
                                </div>
                                
                                
                                <div class="portlet-body">

                                    <div class="table-toolbar">
                                   
                                        <div class="row">
                                            
                                            <div class="col-md-12">
                                                <div class="btn-group pull-right">
                                                    <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">الادوات
                                                        <i class="fa fa-angle-down"></i>
                                                    </button>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-print"></i> طباعه  </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-pdf-o"></i> حفظ ك  PDF </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-excel-o"></i> تصدير الى  Excel </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    
                             <div class="well table-toolbar">
                                <form id="searchform" name="searchform" method="get">

                                        <div class="row">
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">رقم الاوردر</label>
                                                <input name="order_no" type="search" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">التاريخ</label>
                                                <input name="date" type="search" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">الحالة</label>
                                                <select name="state" type="search" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                   <option></option>
                                                    <option value="جديد"> جديد</option>
                                                    <option value="جارى الشحن"> جارى الشحن</option>
                                                    <option value="تم التسليم"> تم التسليم</option>
                                                    <option value="مكتمل"> مكتمل</option>
                                                    <option value="ملغى"> ملغى</option>
                                                    <option value="مرتجع"> مرتجع</option>
                                                    <option value="انتهى الوقت"> انتهى الوقت</option>
                                                    <option value="محجوز"> محجوز</option>
                                                </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">اسم العميل</label>
                                                <input name="cname" type="search" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                          
                                        </div>    
                                        <div class="row">    
                                            <div class="col-md-4 col-sm-4">
                                               
                                                <button type="button" class="btn green" id="filter">
                                                   <li class="fa fa-search"></li> بحث
                                                </button>
                                               
                                            </div> 
                                        </div>  
                                        </form>    
                                    </div>

                                     <div id="reloaddiv">
                                        <div id="searchlist"></div>
                                        <?php echo $__env->make('admin.pages.orders.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    


<!-- Modal -->
<div id="delet_model">
    
</div>
<div id="editmodel">
    
</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/global/plugins/bootbox/bootbox.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>


<script type="text/javascript">
    function formFilter(){
    var data = $("#searchform").serialize();
    $.ajax({
        url: '<?php echo e(url("orders/search")); ?>' , 
        type: "GET",
        data: data,
        beforeSend: function(){
            $('#filter').button('loading');
        },
        success: function(result){              
            $("#searchlist").html(result);
             $('#sample_1').dataTable();
         
             $('#filter').button('reset');
             $('.tooltips').tooltip();
        },
        error: function(error){

        }
    });
};
    
$("#filter").click(formFilter);
$("#filter").trigger("click");
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-level-script'); ?>
<script src="<?php echo e(asset('assets/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript"></script>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>