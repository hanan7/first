<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<!-- add modal -->
<div id="add" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <form  id="addform" action="<?php echo e(URL('attributes/create')); ?>" method="post" >
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">اضافة متغير جديد</h4>
          </div>
          <div class="modal-body col-md-12">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              <div class="row">
                <div class="col-md-9">
                  <label class="control-label"> اسم المتغير</label>
                  <input type="text" name="name" id="name" class="form-control">
                </div>
              </div>
               <div class="row">
                <div class="col-md-9">
                  <label class="control-label"> نوع المتغير</label>
                  <input type="text" name="type" id="type" class="form-control">
                </div>
              </div>
          </div>
          <div class="modal-footer">
            <button type="submit" id="addbutton"  class="btn btn green" name="submit" value="submit"><li class="fa fa-check"></li> اضافة</button>
            <button type="button" class="btn btn-default" data-dismiss="modal"> <li class="fa fa-times"></li> الغاء</button>
          </div>
        </form>
      </div>
    </div>
</div>
<!-- End add modal -->
<!-- delete modal -->
<div id="delete" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    <form  id="deleteform" action="<?php echo e(URL('attributes/'.'delete/' . $all->id)); ?>" method="post" >
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">مسح عنصر</h4>
      </div>
      <div class="modal-body">
        <p>هل تريد تأكيد عملية المسح ؟</p>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn red " value="submit"><li class="fa fa-trash"></li> مسح</button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><li class="fa fa-times"></li> الغاء</button>
      </div>
    </form>  
    </div>

  </div>
</div>
<!-- End delete modal -->
<!-- update modal -->
<div id="update"  class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <form  id="updateform"  action="post"  class="form-horizontal" >
        <?php echo csrf_field(); ?>

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">تعديل متغير</h4>
        </div>
                                         
        <div class="modal-body col-md-12">
          
            <div class="row">
              <div class="col-md-9">
                <label class="control-label"> تعديل الاسم</label>
                <input type="text" name="name"  value="<?php echo e($all->name); ?>" id="name" class="form-control">
              </div>
            </div>
        </div>

        <div class="modal-footer">
          <button type="submit"  name="submit" class="btn btn green btnedit1" ><li class="fa fa-pencil"> تعديل</button>
          <button type="button" class="btn btn-default" data-dismiss="modal"><li class="fa fa-times"> الغاء</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End update modal -->
<?php echo $__env->make("admin.pages.settings.attributes._js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--loadmodal-->
<div id="loadmodel" class="modal fade in" id="ajax" role="dialog" style="display:none; padding-right: 17px;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/admin/global/img/ajax-loading.gif')); ?>" alt="" class="loading">
        <span> &nbsp;&nbsp;Loading... </span>
      </div>
    </div>
  </div>
</div>
 <!-- end load--> 

<script type="text/javascript">
    $(".btnedit1").click(function(){
    
    var id  = <?php echo e($all->id); ?>

    var form1 = document.forms.namedItem("updateform");
    var data = new FormData(form1);
   $.ajax({
      url:"<?php echo e(url('attributes/update')); ?>"+"/"+id,
      type:'post',
      headers: {
        'X-CSRF-Token': $('meta[name="_token"]').attr('content')
      },
      processData:false,
      data:data,
      contentType:false,
      beforeSend: function(){
              $("#loadmodel").show();
      },
     success: function( data ) {
              window.location.reload(); 
                },
      error:function(data){
         $("#loadmodel").remove();
        $(".dele").remove();
       $(".alert-danger").show();
       
      },
    });
});
</script>
