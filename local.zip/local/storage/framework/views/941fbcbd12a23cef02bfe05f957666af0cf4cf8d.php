<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                               <tr>
                                                <th>
                                                    <input type="checkbox" class="group-checkable text-center" data-set="#sample_1 .checkboxes" /> </th>
                                                <th> رقم الاوردر</th>
                                                <th width="10%"> اسم العميل </th>
                                                <th> حالة الاوردر </th>
                                                <th> الاجمالى </th>
                                                <th> تاريخ الاضافة </th>
                                                <th> اسم المضيف</th>
                                                <th class="text-center"> العمليات </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        
                                             <?php foreach($all as $order): ?>
                                            <tr class="odd gradeX">
                                                <td class="text-center">
                                                    <input type="checkbox" class="checkboxes" value="1" /> </td>
                                                <td> 
 
                                                  <?php echo e($order->id); ?>

                                                </td>
                                              
                                                <td><?php echo e($order->users->name); ?></td>
                                                <td><?php echo e($order->status); ?></td>
                                                <td class="center"><?php echo e($order->total); ?></td>
                                                <td class="center"><?php echo e($order->created_at); ?></td>
                                                <td class="center">admin</td>

                                                <td>
                                                <a href="<?php echo e(URL('orders/'.'view-details/'.$order->id)); ?>" data-toggle="tooltip" title class="btn btn blue" data-original title="عرض">
                                                  <li class="fa fa-eye"> عرض</li>
                                                </a>
                                               
                                                <a id="<?php echo e($order->id); ?>" class="btn red btn_delete" data-original title="مسح">
                                                  <li class="fa fa-trash">  مسح</li>
                                                </a>
                                                </td>
                                            </tr> 
                                        <?php endforeach; ?>
                                           
                                        </tbody>
                                    </table>
 