<?php $__env->startSection('content'); ?>
<div id="wrap">
        <div class="slide">
            <div class="comtainer-fluid over">
                <div class="row">
                </div>
            </div>
        </div>
        <div class="search">
            <div class="container">
                <div class="row">
                    <div class="search-tab">
                        <div class="panel with-nav-tabs panel-default">
                            <div class="panel-heading">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab1default" data-toggle="tab">
                                            <span class="flaticon-history"></span> رحلات سياحية
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab2default" data-toggle="tab">
                                            <span class="flaticon-trip-building"></span> فنادق
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab3default" data-toggle="tab">
                                            <span class="flaticon-airplane"></span> تذاكر طيران
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab4default" data-toggle="tab">
                                            <span class="flaticon-bus"></span> ليموزين
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade in active" id="tab1default">
                                        <p>
                                            إبحث عن رحلتك فى أى مكان :
                                        </p>

                                        <form>
                                            <div class="form-group">
                                                <input type="text" placeholder="المكان الذى تود الذهاب إليه" class="form-control" name="place" required>
                                                <input type="text" id="datepicker" placeholder="ميعاد الحجز" class="form-control"  name="time">
                                                <input type="text" placeholder="عدد الأفراد" class="form-control">

                                            </div>
                                            <button class="btn btn-default" type="submit" name="submit">بحـث</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab2default">
                                        <p>
                                            إحجز فى أى فنـدق :
                                        </p>

                                        <form>
                                            <div class="form-group">
                                                <input type="text" placeholder="المكان الذى تود الذهاب إليه" class="form-control" required>
                                                <input type="text" id="datepicker-2" placeholder="ميعاد الحجز" id="datepicker" class="form-control" required>
                                                <input type="text" placeholder="عدد الليالى" class="form-control" required>
                                                <input type="text" placeholder="عدد الأفراد" class="form-control" required>
                                            </div>
                                            <button class="btn btn-default">بحـث</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab3default">
                                        <p>
                                            إحجز تذكرة طيران الأن :
                                        </p>

                                        <form>
                                            <div class="form-group">
                                                <input type="text" placeholder="مكان المغادرة" class="form-control" required>
                                                <input type="text" placeholder="مكان الوصول" class="form-control" required>
                                                <input type="text" placeholder="ميعاد الحجز" id="datepicker-3" class="form-control" required>
                                                <select type="text" class="form-control">
                                                    <option>ذهاب فقط</option>
                                                    <option>ذهاب وعودة</option>

                                                </select>

                                                <input type="text" placeholder="الأسم" class="form-control" required>
                                                <input type="text" placeholder="رقم التليفون" class="form-control" required>
                                                <input type="text" placeholder="البريد الألكترونى" class="form-control" required>
                                                <input type="text" placeholder="عدد الأفراد" class="form-control" required>
                                            </div>
                                            <button class="btn btn-default">حجز</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab4default">
                                        <p>
                                            إحجز ليموزين الأن :
                                        </p>

                                        <form>
                                            <div class="form-group">
                                                <input type="text" placeholder="مكان المغادرة" class="form-control" required>
                                                <input type="text" placeholder="مكان الوصول" class="form-control" required>
                                                <input type="text" placeholder="ميعاد الحجز" id="datepicker-4" class="form-control" required>
                                                <select type="text" class="form-control">
                                                    <option>ذهاب فقط</option>
                                                    <option>ذهاب وعودة</option>

                                                </select>

                                                <input type="text" placeholder="الأسم" class="form-control" required>
                                                <input type="text" placeholder="رقم التليفون" class="form-control" required>
                                                <input type="text" placeholder="البريد الألكترونى" class="form-control" required>
                                                <input type="text" placeholder="عدد الأفراد" class="form-control" required>
                                            </div>
                                            <button class="btn btn-default">حجز</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End search section -->
        <div class="clear"></div>
      

         <!-- End Features section -->
        <div class="clear"></div>
         <!-- Start trips section -->
        <div class="most-popular">
            <div class="container">
                <div class="row text-center">
                    <h1>
                        نتائج البحث عن الرحلات
                    </h1>
                    <div class="border">
                        <hr>
                        <span></span>
                    </div>
            <?php if(count($data) === 0): ?>
                     <p>لا يوجد نتائج ...</p>
            <?php elseif(count($data) >= 1): ?>    
                <?php foreach($data as $trip): ?>    
                    <div class="course">
                        <div class="course-img">
                            <img src="<?php echo e(url('uploads/trips/' . $trip->image . '')); ?>">
                            <div class="course-hover">
                                <a href="">
                                    <button class="btn btn-default">مزيد عن الفندق</button>
                                </a>

                            </div>
                        </div>
                        <div class="course-details">
                            <h2>
                            <?php echo e($trip->trip_name); ?>

                            </h2>
                            <div class="trip-rate">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                        </div>
                        <div class="course-another-det">
                            <p>
                                <?php echo e($trip->short_desc); ?>

                            </p>

                        </div>
                        <div class="book-trip">
                            <a href="<?php echo e(url('trip/booking')); ?>">
                                <button class="btn btn-default">إحجز الأن</button>
                            </a>
                            <p><?php echo e($trip->price); ?></p>

                        </div>

                    </div>
                <?php endforeach; ?> 
            <?php endif; ?>        
                    <div class="more">
                        <a href="<?php echo e(url('trip/trips')); ?>">
                            <button class="btn btn-default">مزيد من الفنادق</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>