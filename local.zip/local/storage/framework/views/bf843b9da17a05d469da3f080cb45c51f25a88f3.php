<?php $__env->startSection("title"); ?>
المندوبين
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
    rel="stylesheet" type="text/css" />
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">المندوبين</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="<?php echo e(url('/admin')); ?>">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">المندوبين</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

<?php if(session()->has('success')): ?>
 <?php $a=[];
 $a = session()->pull('success');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
 <?php if(session()->has('danger')): ?>
 <?php $a=[];
 $a = session()->pull('danger');
 ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
 
  <div class="row">
    <div class="col-md-12">
      <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
        <div class="portlet box blue">
                    <div class="portlet-title">
                      <div class="caption">
                        <i class="icon-pencil"></i>
                           تعديل مندوب
                      </div>
                    </div>

                    <div  class="portlet-body form">
                       <form method="post" name="settingform" action="<?php echo e(URL('delegates/edit/'.$old->id)); ?>"  id="settingform" class="horizontal-form"  files="true" enctype="multipart/form-data">
                           <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                            
                            <div class="form-body">
                              <h3 class="form-section">تعديل مندوب</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">كود المندوب</label>
                                        <input type="text" id="code" name="code" class="form-control" 
                                        value="<?php echo e($old->code); ?>">
                                      </div>
                                    </div>
                                
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">اسم المندوب</label>
                                        <input type="text" id="name" name="name" class="form-control"
                                        value="<?php echo e($old->name); ?>">
                                      </div>
                                    </div>
                                </div>  
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">العنوان</label>
                                        <input type="text" id="address" name="address"  class="form-control"
                                        value="<?php echo e($old->address); ?>" >
                                      </div>
                                  </div>
                                
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">التليفون</label>
                                        <input type="number" id="phone" name="phone"  class="form-control"
                                        value="<?php echo e($old->phone); ?>" >
                                      </div>
                                  </div>
                                </div>   
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">خط السير</label>
                                        <input type="text" id="traffic" name="traffic" class="form-control"
                                        value="<?php echo e($old->traffic); ?>">
                                      </div>
                                  </div>
                                
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">رقم السيارة</label>
                                        <input type="number" id="carnumber" name="carnumber" class="form-control" 
                                        value="<?php echo e($old->carnumber); ?>">
                                      </div>
                                    </div>
                                </div> 
                               <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">نوع العمل</label>
                                        <select class="form-control" name="sortwork">
                                        <option value="يومى"> يومى </option>
                                        <option value="شهرى"> شهرى </option>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">نوع المندوب</label>
                                        <select class="form-control" name="type">
                                        <option value="مندوب تسليم"> مندوب تسليم </option>
                                        <option value="مندوب مبيعات"> مندوب مبيعات </option>
                                        </select>
                                      </div>
                                    </div>
                                </div>

                                <div class="row">   
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">التقييم</label>
                                        <input type="text" id="numberpoint" name="numberpoint" class="form-control" 
                                        value="<?php echo e($old->numberpoint); ?>" placeholder="التقييم من 1 ل 5">
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">الراتب</label>
                                        <input type="text" id="salary" name="salary" class="form-control" 
                                        value="<?php echo e($old->salary); ?>">
                                      </div>
                                    </div>
                                </div>
                                
                                <h5>العهدة</h5>
                                <div class="row">   
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <input type="text" id="money" name="money" class="form-control" 
                                        placeholder="عهدة مالية" value="<?php echo e($old->money); ?>">
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <input type="text" id="properties" name="properties" class="form-control" placeholder="اشياء اخرى" value="<?php echo e($old->properties); ?>">
                                      </div>
                                    </div>
                                </div>

                               <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">نقاط رئسية</label>
                                         <input type="text" id="properties" 
                                         name="main_point"
                                         value="<?php echo e($old->main_point); ?>"
                                          class="form-control" placeholder="" >
                                       
                                      </div>
                                    </div>
                                    <div class="col-md-6">

                                      <div class="form-group">
                                        <label class="control-label">نقاط فرعية</label>
                                         <input type="text" 
                                         id="properties" name="plus_point"
                                         value="<?php echo e($old->plus_point); ?>"
                                          class="form-control" placeholder="" >
                                       
                                      </div>
                                      
                                    </div>
                                </div>     
                                 
                              
                            </div>  
                          <div class="form-actions">
                            <div class="col-md-12 text-center" >
                              <button type="submit"  name="submit" class="btn green btn_save">
                              <i class="fa fa-pencil"></i> تعديل</button>
                              <a href="<?php echo e(url('delegates/all-delegates')); ?>" type="button" class="btn default btn_save">
                              <i class="fa fa-times"></i> الغاء</a> 
                            </div>      
                          </div>
                        </form>
                    </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>                     
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>