    <div id="tooplate_header" style="background-color:#060">
        
      <a href="#"> <img src="<?php echo e(URL('assets/front/images/tooplate_logo2.jpg')); ?>"  width="300" height="90" style="margin-top:-10px; margin-left:300px;"/></a>
        
        <div class="cleaner"></div>
    </div>
    
    <div id="tooplate_menu">
        <ul>
            <li><a href="<?php echo e(url('home/index')); ?>" class="current">الرئيسيه</a></li>
            <li><a href="<?php echo e(url('home/about')); ?>">خدمتنا</a></li>
            <li><a href="news.html">تسجيل دخول</a></li>
            <li class="last"><a href="contact.html">اتصل بنا</a></li>
        </ul>       
        
        
        
        <div class="cleaner"></div>
    </div> <!-- end of tooplate_menu -->
    