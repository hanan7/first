<?php $__env->startSection("title"); ?>
عرض تفاصيل حجز
<?php $__env->stopSection(); ?>
<?php $__env->startSection("page-style"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
              rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">عرض تفاصيل حجز</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">عرض تفاصيل حجز</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
      <div class="portlet box green">
                    <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-eye"></i>
                                    عرض تفاصيل حجز
                                </div>
                    </div>

      <div  class="portlet-body form">
      <div class="form-body">              
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">اسم العميل</label>
              <div class="input-icon right">
                <input type="text"  name="name" value="<?php echo e($old->agent->name); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">التليفون</label>
              <div class="input-icon right">
                <input type="number"   name="phone" value="<?php echo e($old->agent->phone); ?>" class="form-control " >
              </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">الايميل</label>
              <div class="input-icon right">
                <input type="email" name="email" value="<?php echo e($old->agent->email); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">العنوان</label>
              <div class="input-icon right">
                <input type="text"   name="address" value="<?php echo e($old->agent->address); ?>" class="form-control " >
              </div>
          </div>
        </div> 
  
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">عدد المسافرين</label>
              <div class="input-icon right">
                <input type="number"  name="agents_num"  value="<?php echo e($old->agents_num); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">عدد الاطفال</label>
              <div class="input-icon right">
                <input type="number"   name="children" value="<?php echo e($old->children); ?>" class="form-control " >
              </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">من:</label>
              <div class="input-icon right">
                <input type="text"  name="place_from"  value="<?php echo e($old->place_from); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">الى:</label>
              <div class="input-icon right">
                <input type="text"   name="to_place" value="<?php echo e($old->to_place); ?>" class="form-control " >
              </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">اسم الكارت</label>
              <div class="input-icon right">
                <input type="text"  name="credit_name" value="<?php echo e($old->credit_name); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">رقم الكارت</label>
              <div class="input-icon right">
                <input type="number"   name="credit_num" value="<?php echo e($old->credit_num); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
        </div> 
        <div class="row">
          <div class="col-md-6">
            <label class="control-label bold">تاريخ الانتهاء</label>
              <div class="input-icon right">
                <input type="text"  name="credit_date" value="<?php echo e($old->credit_date); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
          <div class="col-md-6">
            <label class="control-label bold">الرقم السرى</label>
              <div class="input-icon right">
                <input type="number"   name="credit_password" value="<?php echo e($old->credit_password); ?>" class="form-control " aria-controls="sample">
              </div>
          </div>
        </div>
      </div>                 
      </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>