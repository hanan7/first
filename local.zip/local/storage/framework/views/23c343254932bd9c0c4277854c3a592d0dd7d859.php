<?php $__env->startSection('content'); ?>    
    <div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ رحلات المضيــف ـــــــ
                        <p>
                            <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            | رحلات سياحية
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="trips-content">
            <div class="container">
                <div class="row text-center">
                <form action="<?php echo e(url('trip/search-filter')); ?>" method="get">
                    <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="fliter">
                        <div class="panel-group" id="accordion">
                            <div class="panel panel-default">
                                <a>
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                    عدد الأيام
                                   <i class="fa fa-angle-down"></i>
                                </h4>
                                    </div>
                                </a>
                                <div id="collapseOne" class="panel-collapse collapse in">
                                    <div class="panel-body">
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="oneday" class="form-control"> يوم واحد
                                                <span>[8]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox"  name="twodays" class="form-control"> يومين
                                                <span>[4]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox"  name="three" class="form-control"> 3 أيام
                                                <span>[25]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="four" class="form-control"> 4 أيام
                                                <span>[19]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="five" class="form-control"> 5أيام
                                                <span>[17]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="six" class="form-control"> 6أيام
                                                <span>[17]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="week" class="form-control"> أسبوع
                                                <span>[17]</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <input type="checkbox" name="more" class="form-control"> أكثر من ذلك
                                                <span>[17]</span>
                                            </a>
                                        </li>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <a>
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                    السعر
                                   <i class="fa fa-angle-down"></i>
                                </h4>
                                        </div>
                                    </a>
                                    <div id="collapseOne" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                            <li>
                                                <a href="#" id="spec-font">
                                                    <input type="checkbox" name="cheap" class="form-control"> 50 $ - 100 $
                                                    <span>[14]</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" id="spec-font">
                                                    <input type="checkbox" name="cheap1" class="form-control"> 100 $ - 200 $
                                                    <span>[28]</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" id="spec-font">
                                                    <input type="checkbox" name="exp" class="form-control"> 200 $ - 400 $
                                                    <span>[14]</span>
                                                </a>
                                            </li>

                                            <li>
                                                <a href="#" id="spec-font">
                                                    <input type="checkbox" name="exp1" class="form-control"> 400 $ - 600 $
                                                    <span>[10]</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" id="spec-font">
                                                    <input type="checkbox" name="exp2" class="form-control"> 600 $ - 800 $
                                                    <span>[8]</span>
                                                </a>
                                            </li>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                        </div>
                    </div>
                </form>    
                    <div class="all-trips">
                <?php foreach($trip as $trip): ?>    
                    <div class="course">
                        <div class="course-img">
                            <img src="<?php echo e(url('uploads/trips/' . $trip->image . '')); ?>">
                            <div class="course-hover">
                                <a href="<?php echo e(url('trip/' . 'trip-details/' . $trip->id)); ?>">
                                    <button class="btn btn-default">تفاصيل الرحلة</button>
                                </a>
                            </div>
                        </div>
                        <div class="course-details">
                            <h2>
                           <?php echo e($trip->trip_name); ?>

                            </h2>
                            <div class="hotel-rate">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                        </div>
                        <div class="course-another-det">
                            <p>
                                <?php echo e($trip->short_desc); ?>

                            </p>

                        </div>
                        <div class="book-trip">
                            <a href="<?php echo e(url('trip/booking')); ?>">
                                <button class="btn btn-default">إحجز الأن</button>
                            </a>
                            <p><?php echo e($trip->price); ?> $</p>

                        </div>

                    </div>
                <?php endforeach; ?>  
                   
                       
                
                        <ul class="pagination">
                            <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#">6</a></li>
                            <li><a href="#">7</a></li>
                            <li><a href="#">8</a></li>
                            <li><a href="#">9</a></li>
                            <li><a href="#">10</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>