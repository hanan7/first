<?php $__env->startSection('content'); ?>
<div id="wrap">
        <div class="slide">
            <div class="comtainer-fluid over">
                <div class="row">
                </div>
            </div> 
        </div>
        <div class="search">
            <div class="container">
                <div class="row">
                    <div class="search-tab">
                        <div class="panel with-nav-tabs panel-default">
                            <div class="panel-heading">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab1default" data-toggle="tab">
                                            <span class="flaticon-history"></span> رحلات سياحية
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab2default" data-toggle="tab">
                                            <span class="flaticon-hotel-building"></span> فنادق
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab3default" data-toggle="tab">
                                            <span class="flaticon-airplane"></span> تذاكر طيران
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tab4default" data-toggle="tab">
                                            <span class="flaticon-bus"></span> ليموزين
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade in active" id="tab1default">
                                        <p>
                                            إبحث عن رحلتك فى أى مكان :
                                        </p>

                                        <form action="<?php echo e(url('home/trip-search')); ?>" method="get">
                                        <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="form-group">
                                                <input type="text" placeholder="المكان الذى تود الذهاب إليه" class="form-control" name="place">
                                                <input type="text" id="datepicker" placeholder="ميعاد الحجز" class="form-control"  name="time">
                                              
                                            </div>
                                            <button class="btn btn-default" type="submit" name="submit">بحـث</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab2default">
                                        <p>
                                            إحجز فى أى فنـدق :
                                        </p>

                                        <form action="<?php echo e(url('home/hotel-search')); ?>" method="get">
                                        <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="form-group">
                                                <input type="text" placeholder="المكان الذى تود الذهاب إليه" class="form-control"  name="place">
                                                <input type="text" id="datepicker-2" placeholder="ميعاد الحجز" id="datepicker" class="form-control" name="time">
                                                <input type="text" placeholder="سعر الليلة" class="form-control" name="price">
                                                
                                            </div>
                                            <button class="btn btn-default">بحـث</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab3default">
                                        <p>
                                            إحجز تذكرة طيران الأن :
                                        </p>

                                        <form role="form" action="<?php echo e(url('home/book-plan')); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="form-group">
                                                 <input type="text" placeholder="الأسم" name="name" class="form-control" required>
                                                <input type="text" placeholder="رقم التليفون"  name="phone" class="form-control" required>
                                                <input type="text" placeholder="البريد الألكترونى" name="email" class="form-control" required>
                                                <input type="text" placeholder="العنوان" name="address" class="form-control" required>
                                                <input type="text" placeholder="الذهاب  من " class="form-control"  name="place_from">

                                                <input type="text" placeholder="الذهاب  إلى " class="form-control" required name="to_place">

                                                <input type="text" id="datepicker" placeholder="تاريخ الذهاب" class="form-control" required name="start_date">

                                                <input type="text" id="datepicker-2" placeholder=" تاريخ العودة" class="form-control" required name="end_date">

                                                <input type="text" placeholder=" عدد الافراد" class="form-control" required name="agents_num">
                                                
                                                <input type="text" placeholder="عدد الاطفال" name="children" class="form-control">

                                                <select type="text" name="seat" class="form-control">
                                                    <option>نوع المقعد</option>
                                                    <option value="إقتصادى">إقتصادى</option>
                                                    <option value="رجال أعمال">رجال أعمال</option>
                                                </select>
                                                <select type="text" name="go_back" class="form-control">
                                                    <option value="ذهاب فقط">ذهاب فقط</option>
                                                    <option value="ذهاب وعودة">ذهاب وعودة</option>
                                                </select>
                                            </div>
                                            <button type="submit" name="submit" class="btn btn-default">حجز</button>
                                        </form>

                                    </div>
                                    <div class="tab-pane fade" id="tab4default">
                                        <p>
                                            إحجز ليموزين الأن :
                                        </p>

                                        <form role="form" action="<?php echo e(url('home/book-lemo')); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="form-group">
                                                <input type="text" name="name" placeholder="الأسم" class="form-control" required>
                                                <input type="text" name="phone" placeholder="رقم التليفون" class="form-control"  required>
                                                <input type="text" name="email" placeholder="البريد الألكترونى" class="form-control" required>
                                                <input type="text" placeholder="العنوان" name="address" class="form-control" required>
                                                <input type="text" name="place_from" placeholder="مكان المغادرة" class="form-control" required>
                                                <input type="text" name="to_place" placeholder="مكان الوصول" class="form-control" required>
                                                <input type="text" id="datepicker" placeholder="تاريخ الذهاب" class="form-control" required name="start_date">

                                                <input type="text" id="datepicker-2" placeholder=" تاريخ العودة" class="form-control" required name="end_date">

                                                <input type="text" placeholder=" عدد الافراد" class="form-control" required name="agents_num">
                                                
                                                <input type="text" placeholder="عدد الاطفال" name="children" class="form-control">

                                                <input type="text" name="bags_num" placeholder="عدد الحقائب" class="form-control" required>
                                                  
                                                <select type="text" name="go_back" class="form-control">
                                                    <option value="ذهاب فقط">ذهاب فقط</option>
                                                    <option value="ذهاب وعودة">ذهاب وعودة</option>
                                                </select>

                                               
                                            </div>
                                            <button type="submit" name="submit" class="btn btn-default">حجز</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End search section -->
        <div class="clear"></div>
        <!-- Start trips section -->
        <div class="most-popular">
            <div class="container">
                <div class="row text-center">
                    <h1>
                         رحـلات سياحيــة
                    </h1>
                    <div class="border">
                        <hr>
                        <span></span>
                    </div>
                <?php foreach($trip as $trip): ?>    
                    <div class="course">
                        <div class="course-img">
                            <img src="<?php echo e(url('uploads/trips/' . $trip->image . '')); ?>">
                            <div class="course-hover">
                                <a href="<?php echo e(url('trip/' . 'trip-details/' . $trip->id)); ?>">
                                    <button class="btn btn-default">تفاصيل الرحلة</button>
                                </a>
                            </div>
                        </div>
                        <div class="course-details">
                            <h2>
                           <?php echo e($trip->trip_name); ?>

                            </h2>
                            <div class="hotel-rate">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                        </div>
                        <div class="course-another-det">
                            <p>
                                <?php echo e($trip->short_desc); ?>

                            </p>

                        </div>
                        <div class="book-trip">
                            <a href="<?php echo e(url('trip/booking')); ?>">
                                <button class="btn btn-default">إحجز الأن</button>
                            </a>
                            <p><?php echo e($trip->price); ?> $</p>

                        </div>

                    </div>
                <?php endforeach; ?>  
                    <div class="more">
                        <a href="<?php echo e(url('trip/trips')); ?>">
                            <button class="btn btn-default">مزيد من الرحلات</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End trips section -->
        <div class="clear"></div>
        <!-- Start Features section -->
        <div class="features">
            <div class="container-fluid over">
                <div class="row text-center">
                    <img src="">
                    <h4> تمتع معنا بخدمة متميزة وأسعار مناسبة</h4>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
            </div>
        </div>
         <!-- End Features section -->
        <div class="clear"></div>
         <!-- Start hotels section -->
        <div class="most-popular">
            <div class="container">
                <div class="row text-center">
                    <h1>
                        الفنادق
                    </h1>
                    <div class="border">
                        <hr>
                        <span></span>
                    </div>
                <?php foreach($hotel as $hotel): ?>    
                    <div class="course">
                        <div class="course-img">
                            <img src="<?php echo e(url('uploads/hotels/' . $hotel->image . '')); ?>">
                            <div class="course-hover">
                                <a href="<?php echo e(url('hotel/' . 'hotel-details/' . $hotel->id)); ?>">
                                    <button class="btn btn-default">مزيد عن الفندق</button>
                                </a>

                            </div>
                        </div>
                        <div class="course-details">
                            <h2>
                            <?php echo e($hotel->hotel_name); ?>

                            </h2>
                            <div class="hotel-rate">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                        </div>
                        <div class="course-another-det">
                            <p>
                                <?php echo e($hotel->short_desc); ?>

                            </p>

                        </div>
                        <div class="book-trip">
                            <a href="<?php echo e(url('hotel/booking')); ?>">
                                <button class="btn btn-default">إحجز الأن</button>
                            </a>
                            <p><?php echo e($hotel->price); ?></p>

                        </div>

                    </div>
                <?php endforeach; ?>    
                    <div class="more">
                        <a href="<?php echo e(url('hotel/hotels')); ?>">
                            <button class="btn btn-default">مزيد من الفنادق</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
         <!-- End hotels section -->
        <div class="clear"></div>
         <!-- Start about section -->
        <div class="about">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-24-hours-support"></span>
                            <h1>
                                 <i>24</i>
                                ساعة خدمة عملاء
                            </h1>
                            <p>
                                اتصل بنا فى اى وقت وستجد دائما غايتك لدينا
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-map-with-position-marker"></span>
                            <h1>
                                 <i>+ <?php echo e($sections->trips_num); ?></i>
                                رحلة سياحية
                            </h1>
                            <p>
                                <?php echo e($sections->trips_desc); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="serv">
                            <span class="flaticon-man-travelling"></span>
                            <h1>
                                 <i>+ <?php echo e($sections->agents_num); ?></i>
                              عميل
                            </h1>
                            <p>
                                <?php echo e($sections->trips_desc); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>