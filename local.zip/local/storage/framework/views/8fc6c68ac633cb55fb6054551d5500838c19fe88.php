<?php $__env->startSection('content'); ?> 
<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('success')); ?> </p>
    
    </div>
 <?php endif; ?>    
    <div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ ليموزين ـــــــ
                        <p>
                            <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            | ليموزين
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content" id="plan-content">
            <div class="container">
                <div class="row">
                    <form role="form" action="<?php echo e(url('home/book-lemo')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="tab-content">
                            <div class="tab-pane" >
                                <h3>
                                 <span class="glyphicon glyphicon-user"></span>
                                 البيانات الشخصية
                             </h3>
                                <div class="col-lg-8 col-md-8 col-sm-12">
                                    <div class="form-body">
                                        <form>
                                            <div class="form-group">
                                               <input type="text" placeholder="الأسم" name="name" class="form-control" required>
                                                <input type="text" placeholder="رقم التليفون"  name="phone" class="form-control" required>
                                                <input type="text" placeholder="البريد الألكترونى" name="email" class="form-control" required>
                                                <input type="text" placeholder="العنوان" name="address" class="form-control" required>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="serv">
                                        <span class="flaticon-airplane"></span>
                                        <h1>
                                         <i>+ <?php echo e($sections->trips_num); ?></i>
                                         رحلة  طيران
                                     </h1>
                                        <p>
                                           <?php echo e($sections->trips_desc); ?>

                                        </p>
                                    </div>
                                </div>

                                <h3>
                                 <span class="glyphicon glyphicon-plane"></span>
                                 بيانات الحجز
                                </h3>
                                <div class="col-lg-8 col-md-8 col-sm-12">
                                    <div class="form-body" id="special-form">
                                       

                                            <div class="form-group" id="special-form">
                                                <input type="text" placeholder="الذهاب  من " class="form-control"  name="place_from">

                                                <input type="text" placeholder="الذهاب  إلى " class="form-control" required name="to_place">

                                                <input type="text" id="datepicker" placeholder="تاريخ الذهاب" class="form-control" required name="start_date">

                                                <input type="text" id="datepicker-2" placeholder=" تاريخ العودة" class="form-control" required name="end_date">

                                                <input type="text" placeholder=" عدد الافراد" class="form-control" required name="agents_num">
                                                
                                                <input type="text" placeholder="عدد الاطفال" name="children" class="form-control">

                                                <input type="text" name="bags_num" placeholder="عدد الحقائب" class="form-control" required>
                                                  
                                                <select type="text" name="go_back" class="form-control">
                                                    <option value="ذهاب فقط">ذهاب فقط</option>
                                                    <option value="ذهاب وعودة">ذهاب وعودة</option>
                                                </select>
                                            </div>
                                        
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="serv">
                                        <span class="flaticon-map-with-position-marker"></span>
                                        <h1>
                                         <i>+ <?php echo e($sections->trips_num); ?></i>
                                         رحلة سياحية
                                     </h1>
                                        <p>
                                            <?php echo e($sections->trips_desc); ?>

                                        </p>
                                    </div>
                                </div>
                              
                                <div class="col-lg-8 col-md-8 col-sm-12" >
                                    <ul class="list-inline" style="margin-top:10px;">
                                        <li>
                                            <button type="submit"  class="btn btn-primary">حجز</button>
                                        </li>
                                    </ul>
                                </div>
                              

                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>