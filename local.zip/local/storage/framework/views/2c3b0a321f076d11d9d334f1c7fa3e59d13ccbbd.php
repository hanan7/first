<?php $__env->startSection("title"); ?>
طلبات المعاينة
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />
         
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">طلبات المعاينة</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="<?php echo e(url('/admin')); ?>">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">طلبات المعاينة</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
 <?php if(session()->has('success')): ?>
 <?php $a=[];
 $a = session()->pull('success');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
 <?php if(session()->has('danger')): ?>
 <?php $a=[];
 $a = session()->pull('danger');
 ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>

  	<div class="portlet box blue ">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> عرض طلبات المعاينة</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                <a  href="#addplace" data-toggle="modal" class="btn btn blue" ><i class="fa fa-plus"></i>  اضافة طلب
                </a>
              </div>
            </div>
          
          </div>
        </div>  

      
         <table class="table table-placeiped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
              
                <th class="text-center"> اسم الطلب </th>
                <th class="text-center"> الصورة </th>
                <th class="text-center">العمليات</th>
              </tr>
            </thead>
             
            <tbody>
            <?php foreach($place as $place): ?>
              <tr>
                    <td class="text-center"> <?php echo e($place->name); ?> </td>
                    <td class="text-center"> <img src="<?php echo e(url('uploads/places/'.$place->image)); ?>" style="width:100px; height:100px; "/></td>
                    <td class="text-center">
                     
                     <a href="#deletemodal" data-toggle="modal" class="btn btn-danger btndelet"  >
                          <li class="fa fa-trash">  مسح</li>
                      </a>
                      
                    </td>
              </tr>
              <?php endforeach; ?> 
            </tbody>
          </table>
       
    </div> 
</div>

<!-- Modal -->
<div id="addplace" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">اضافة طلب معاينة</h4>

      </div>
        
          <form method="post" name="productform" action="<?php echo e(url('agents/add-place')); ?>" class=" horizontal-form" files="true" enctype="multipart/form-data">
            <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="modal-body">
                                <div class="row">
                                   <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">اسم الطلب</label>
                                        <input type="text" id="name" name="name" class="form-control " >
                                      </div>
                                    </div>
                                  </div>
                               

                                <div class="row">
                                  <div class="col-md-9">
                                      <div class="form-group">
                                        <label class="control-label">الصورة</label>
                                        <input type="file" id="image" name="image"  class="form-control " >
                                      </div>
                                  </div>
                                </div>  
               
                </div>
    
      <div class="modal-footer">

        <button type="submit" name="submit" class="btn btn green"><li class="fa fa-check"></li> اضافة</button>
     
        <button type="button" class="btn btn dafault" data-dismiss="modal"><li class="fa fa-times"></li> الغاء</button>
    
      </div>
    </form> 
    </div>
  </div>
</div>
<!-- endModal --> 
 
<!-- Modal -->
<div id="deletemodal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title bold">مسح عنصر</h4>
      </div>
      <div class="modal-body">
        <p>هل تريد تأكيد عملية المسح ؟</p>
      </div>
      <div class="modal-footer">

        <a href="<?php echo e(URL('agents/'.'delete/'.$place->id)); ?>" id="delete" class="btn btn red"><li class="fa fa-trash"></li> مسح</a>
     
        <button type="button" class="btn btn dafault" data-dismiss="modal"><li class="fa fa-times"></li> الغاء</button>
    
      </div>
      </form>
    </div>

  </div>
</div
<?php $__env->stopSection(); ?>

<?php $__env->startSection("layoutscripts"); ?>
        <script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("levelscripts"); ?>
 <script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript">
  
 </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>