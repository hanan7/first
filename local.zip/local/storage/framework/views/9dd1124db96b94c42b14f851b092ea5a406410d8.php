<?php $__env->startSection('title'); ?>
المتغيرات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> المتغيرات
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
   	 	<i class="icon-home"></i>
    	<a href="index.html">الصفحة الرئيسية</a>
    	<i class="fa fa-angle-left"></i>
    </li>
    <li>
       	<a href="#">المتغيرات</a>
    </li>                   
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
  <?php endif; ?>


    <div class="portlet box green ">
      <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-plus-circle"></i>اضافة متغير جديد</div>
      </div>

      <div class="portlet-body" >
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                <a  data-target="#addvar" class="btn btn green" data-toggle="modal" ><i class="fa fa-plus"></i>  اضافة متغير
                </a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="btn-group pull-right">
                  <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">الادوات
                    <i class="fa fa-angle-down"></i>
                  </button>
                  <ul class="dropdown-menu pull-right">
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-print"></i> طباعه  </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-file-pdf-o"></i> حفظ ك  PDF </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                      <i class="fa fa-file-excel-o"></i> تصدير الى  Excel </a>
                    </li>
                  </ul>
              </div>
            </div>
          </div>
        </div>
        <div id="reloaddiv">
          <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th width="10%"> رقم المتغير </th>
                <th width="30%"> اسم المتغير</th>
                <th class="text-center"> تاريخ الاضافة</th>
                <th class="text-center"> اسم المضيف</th>
                <th class="text-center">العمليات</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>                                
                <td class="text-center"></td>
                <td class="text-center"></td>
                <td class="text-center">
                  <a id=""  data-toggle="modal"  class="btn green btnedit" data-original="">
                    <li class="fa fa-pencil"> تعديل</li>
                  </a>
                  <a elementId=""   class="btn btn-danger btndelet"  >
                      <li class="fa fa-trash">  مسح</li>
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div> 
    </div> 
                              <!-- modals -->
                                <div id="addvar" class="modal fade" role="dialog">
                                    <div class="modal-dialog">

                                     <!-- Modal content-->
                                      <div class="modal-content">
                                        <form  id="addform" action="<?php echo e(URL('settings/variable')); ?>" method="post" >
                                      
                                         <div class="modal-header">
                                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                                         <h4 class="modal-title">اضافة متغير جديد</h4>
                                         </div>
                                         
                                        <div class="modal-body col-md-12">
                                         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="row">
                                              <div class="col-md-9">
                                                <label class="control-label"> ادخل اسم المتغير</label>
                                             
                                                <input type="text" name="v_name" id="name" class="form-control">
                                           
                                              </div>
                                            </div>
                                        </div>
                                         <div class="modal-footer">
                                         <button type="submit" id="addbutton"  class="btn btn green" name="submit" value="submit"><li class="fa fa-check"></li> اضافة</button>
                                         <button type="button" class="btn btn-default" data-dismiss="modal"> <li class="fa fa-times"></li> الغاء</button>
                                        
                                         </div>
                                        </form>
                                      </div>

                                    </div>
                                </div>

                                <div id="edits_modal">
                                </div>

                                <div id="delet_modal">
                                </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>