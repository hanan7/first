<?php $__env->startSection('content'); ?>     
    <div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ فندق <?php echo e($hotel->hotel_name); ?> ـــــــ
                        <p>
                           <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('hotel/allhotels')); ?>">
                                    /
                                    فنادق
                                </a>
                            </li>
                            / <?php echo e($hotel->hotel_name); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="only-trip-content">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-8 col-sm-12">
                        <div id="pro-carousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner" role="listbox">
                               <?php foreach($hotel->photos as $ph): ?>
                                <div class="item active zoom">
                                    <img class="img-responsive"  src="<?php echo e(url('uploads/' . $ph->images . "")); ?>">
                                </div>
                             
                                <ol class="carousel-indicators">
                                
                                    <li data-target="#pro-carousel" data-slide-to="0">
                                        <img class="img-responsive" src="<?php echo e(url('uploads/' . $ph->images . "")); ?>">
                                    </li>
                                </ol>
                            <?php endforeach; ?>  
                            </div>
                        </div>
                        <div class="trip-information">
                            <ul id="myTab" class="nav nav-tabs nav_tabs">
                                <li class="active"><a href="#trip-one" data-toggle="tab">عن الفندق</a></li>
                                <li><a href="#trip-two" data-toggle="tab">غرف فردية</a></li>
                                <li><a href="#trip-three" data-toggle="tab">غرف مزدوجة</a></li>
                                <li><a href="#trip-four" data-toggle="tab">جناح خاص</a></li>
                                
                            </ul>
                            <div id="myTabContent" class="tab-content">
                                <div class="tab-pane fade in active " id="trip-one">
                                   
                                    <p>
                                    <?php echo e($hotel->long_desc); ?>

                                    </p>
                                </div>
                                <div class="tab-pane fade" id="trip-two">
                                    <div class="day-des">
                                        <h4>
                                                غرفة فردىة
                                            </h4>
                                        <p>
                                            <i class="fa fa-check"></i> <?php echo e($hotel->single_room); ?>

                                        </p>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="trip-three">
                                    <div class="day-des">
                                        <h4>
                                                غرفة مزدوجة
                                            </h4>
                                        <p>
                                            <i class="fa fa-check"></i> <?php echo e($hotel->double_room); ?> 
                                        </p>
                                    
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="trip-four">
                                    <div class="day-des">
                                        <h4>
                                                جناح خاص
                                            </h4>
                                            <?php if(count($hotel->special) === 0): ?>
                                              <p>لا يوجد نتائج ...</p>
                                            <?php endif; ?>
                                        <p>
                                            <i class="fa fa-check"></i> <?php echo e($hotel->special); ?> 
                                        </p>
                                    </div>

                                </div>
                                 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-12">
                        <div class="related">
                            <div class="related-title">
                                <span class="fa fa-thumb-tack"></span> معلومات عن الفندق
                            </div>
                            <div class="main-info">
                                <p>
                                    <span class="fa fa-home"></span> إسم الفندق : فندق <?php echo e($hotel->hotel_name); ?>

                                </p>
                                <p>
                                    <span class="fa fa-map-marker"></span> العنوان : <?php echo e($hotel->short_desc); ?>

                                </p>
                                <p>
                                    <span class="fa fa-usd"></span> سعر الليلة : <?php echo e($hotel->night_price); ?> $
                                </p>
                               
                                <a href="<?php echo e(url('hotel/booking')); ?>">
                                    <button class="btn btn-default">إحجز الأن</button>
                                </a>
                            </div>
                        </div>
                        <div class="related">
                            <div class="related-title">
                                <span class="fa fa-thumb-tack"></span> فنادق متعلقة
                            </div>
                            <?php foreach($same as $same): ?>    
                            <div class="tour-small">
                                <div class="tour-small-img">
                                    <img src="<?php echo e(url('uploads/hotels/' . $same->image . '')); ?>">
                                </div>
                                <div class="tour-small-descrip">
                                    <a href="only-trip.html">
                                        <p>رحلة <?php echo e($same->hotel_name); ?></p>
                                    </a>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star-o"></span>
                                    <a href="<?php echo e(url('hotel/booking')); ?>">
                                        <button class="btn btn-default">إحجز الأن</button>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>  

                        </div>
                        <div class="serv">
                            <span class="flaticon-24-hours-support"></span>
                            <h1>
                                 <i>24</i>
                                ساعة خدمة عملاء
                            </h1>
                            <p>
                                هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>