<?php $__env->startSection('title'); ?>
  الاعدادات العامة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> الاعدادات العامة
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
   	 	<i class="icon-home"></i>
    	<a href="index.html">الصفحة الرئيسية</a>
    	<i class="fa fa-angle-left"></i>
    </li>
    <li>
       	<a href="#">الاعدادات العامة</a>
    </li>                   
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('success')): ?>
   <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('success')); ?> </p>
    
    </div>
<?php elseif(session()->has('danger')): ?>  
   <div class="alert alert-danger alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('danger')); ?> </p>
    
    </div> 
<?php endif; ?>

<?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
<?php endif; ?>
<div class="row">
  <div class="col-md-12">
		<div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
			<div class="portlet box green">
					<div class="portlet-title">
						<div class="caption">
							<i class="icon-settings"></i>الاعدادات العامة
						</div>
					</div>

					  <div class="portlet-body form">
							  <form method="post" action="<?php echo e(url('settings/addstore')); ?>"  class="horizontal-form">
								     <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
									<div class="form-body">
                      <h3 class="form-section">البيانات العامة</h3>
										        <div class="row">
											        <div class="col-md-6">
                      							<div class="form-group">
                          							<label class="control-label">اسم المتجر<span style="color:red;">*</span></label>
                           							<ul class="nav nav-tabs">
                               							<li class="active ">
                                   						<a href="#tab_1" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    					</a>
                                						</li>
                               							<li>
                                  						<a href="#tab_2" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/gb.png')); ?>">
                                   						</a>
                               							</li>
                          							</ul>
                            						<div class="tab-content">
                                						<div class="tab-pane fade active in" id="tab_1">
                                							<div class=" input-icon right">		  
                                     							<input type="text" id="ar_name" name="ar_name" value="" class="form-control required" >
                                   							</div>
                                  						</div>
                                						<div class="tab-pane fade" id="tab_2">
                                							<div class=" input-icon right">	
                                								<input type="text" id="en_name" name="en_name"  class="form-control required " >
                                							</div>
                                						</div>
                            						</div>
                         						</div>
                      				</div>
                      				<div class="col-md-6">
                      							<div class="form-group">
                          							<label class="control-label">العنوان <span style="color:red;">*</span></label>
                           							<ul class="nav nav-tabs">
                               							<li class="active ">
                                   						<a href="#tab_1" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    					</a>
                                						</li>
                               							<li>
                                  						<a href="#tab_2" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/gb.png')); ?>">
                                   						</a>
                               							</li>
                          							</ul>
                            						<div class="tab-content">
                                						<div class="tab-pane fade active in" id="tab_1">
                                							<div class=" input-icon right">		  
                                     							<input type="text" name="ar_address" value="" class="form-control required " >
                                   							</div>
                                  						</div>
                                						<div class="tab-pane fade" id="tab_2">
                                							<div class=" input-icon right">	
                                								<input type="text"  name="en_address"  class="form-control required " >
                                							</div>
                                						</div>
                            						</div>
                         						</div>
                      				</div>													    
										        </div>
							
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">رقم التليفون</label>
														<div class="input-icon right">
															<input type="text" id="phone" name="phone" value="" class="form-control number" >
                              <span class="warning-block">مسموح بالارقام فقط</span>
														</div>
												</div>
											</div>
													
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">الايميل</label>
														<div class="input-icon right">
															<input type="email" id="email"   name="email" value=""  class="form-control" >
														</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">قيمة الشحن</label>
														<div class="input-icon right">
															<input type="number" id="charge" name="charge" value=""  class="form-control  number" >
														</div>
												</div>
											</div>
										</div>
										<hr />

										<h3 class="form-section">مواقع التواصل الاجتماعى</h3>   
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">FB</label>
														<input type="text" name="fb" value="" class="form-control " >	
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">TW</label>
														<input type="text" name="tw" value="" class="form-control">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">G+</label>
														<input type="text" name="gplus" value="" class="form-control " >
												</div>
											</div>
										</div>
									         	 
									    <h3 class="form-section">معلومات SEO</h3> 
									            <div class="row">  
									              <div class="col-md-6">
                      							<div class="form-group">
                          							<label class="control-label">مفتاح ال Meta</label>
                           							<ul class="nav nav-tabs">
                               							<li class="active ">
                                   						<a href="#tab_1" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    					</a>
                                						</li>
                               							<li>
                                  						<a href="#tab_2" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags\gb.png')); ?>">
                                   						</a>
                               							</li>
                          							</ul>
                            						<div class="tab-content">
                                						<div class="tab-pane fade active in" id="tab_1">
                                							<div class=" input-icon right">		  
                                     							<input type="text" id="ar_name" name="meta_keyword" value="" class="form-control " >
                                   							</div>
                                  						</div>
                                						<div class="tab-pane fade" id="tab_2">
                                							<div class=" input-icon right">	
                                								<input type="text" id="en_name" name="en_name"  class="form-control " >
                                							</div>
                                						</div>
                            						</div>
                         						</div>
                      					</div>
                      			  </div>	
										
										    <div class="row">  
									        <div class="col-md-6">
                      							<div class="form-group">
                          							<label class="control-label">عنوان ال Meta</label>
                           							<ul class="nav nav-tabs">
                               							<li class="active ">
                                   						<a href="#tab_1" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    					</a>
                                						</li>
                               							<li>
                                  						<a href="#tab_2" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags\gb.png')); ?>">
                                   						</a>
                               							</li>
                          							</ul>
                            						<div class="tab-content">
                                						<div class="tab-pane fade active in" id="tab_1">
                                							<div class=" input-icon right">		  
                                     							<input type="text" id="ar_name" name="meta_title" value="" class="form-control " >
                                   							</div>
                                  						</div>
                                						<div class="tab-pane fade" id="tab_2">
                                							<div class=" input-icon right">	
                                								<input type="text" id="en_name" name="en_name"  class="form-control " >
                                							</div>
                                						</div>
                            						</div>
                         						</div>
                      		</div>
                      	</div>
										
										    <div class="row">  
									        <div class="col-md-6">
                      							<div class="form-group">
                          							<label class="control-label">وصف ال Meta</label>
                           							<ul class="nav nav-tabs">
                               							<li class="active ">
                                   						<a href="#tab_1" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                    					</a>
                                						</li>
                               							<li>
                                  						<a href="#tab_2" data-toggle="tab" aria-expanded="true">	<img src="<?php echo e(asset('assets/admin/global/img/flags\gb.png')); ?>">
                                   						</a>
                               							</li>
                          							</ul>
                            						<div class="tab-content">
                                						<div class="tab-pane fade active in" id="tab_1">
                                							<div class=" input-icon right">		  
                                     							<textarea type="text" id="ar_name" name="meta_desc" value="" class="form-control " ></textarea>
                                   							</div>
                                  						</div>
                                						<div class="tab-pane fade" id="tab_2">
                                							<div class=" input-icon right">	
                                								<textarea type="text" id="en_name" name="en_name"  class="form-control " ></textarea>
                                							</div>
                                						</div>
                            						</div>
                         						</div>
                      		</div>
                        </div>

						                  <div class="row">
						                	  <div class="col-md-6">
                      						<div class="form-group">
						                        <h4 class="form-section">العملات</h4> 
                                        <div class="md-radio-list">
                                                <div class="md-radio">
                                                    <input name="currency" class="md-radiobtn" id="radio1" type="radio" value="1">
                                                    <label for="radio1">
                                                        <span></span>
                                                        <span class="check"></span>
                                                        <span class="box"></span> درهم</label>
                                                </div>
                                                <div class="md-radio">
                                                    <input name="currency" class="md-radiobtn" id="radio2" type="radio" checked="" value="2">
                                                    <label for="radio2">
                                                        <span></span>
                                                        <span class="check"></span>
                                                        <span class="box"></span> دولار </label>
                                                </div>
                                                <div class="md-radio">
                                                    <input name="currency" class="md-radiobtn" id="radio3" type="radio" value="3">
                                                    <label for="radio3">
                                                        <span></span>
                                                        <span class="check"></span>
                                                        <span class="box"></span> يورو </label>
                                                </div>
                                                <div class="md-radio">
                                                    <input name="currency" class="md-radiobtn" id="radio3" type="radio" value="4">
                                                    <label for="radio3">
                                                        <span></span>
                                                        <span class="check"></span>
                                                        <span class="box"></span> ريال </label>
                                                </div>
                                             
                                        </div>
                                  </div>
                                </div>
                              </div>
                  </div>  

								  <div class="form-actions">
									  <div class="col-md-12 text-center" >
											<button type="submit" name="submit" class="btn green btn_save">
                      <i class="fa fa-check"></i> حفظ</button>
                      <button type="button" class="btn default btn_save">
                      <i class="fa fa-times"></i> الغاء</button> 
                    </div>      
                  </div>
                                
                </form>
					  </div>
			</div>
		</div>
  </div>
</div>       

<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>