<?php $__env->startSection('content'); ?> 
<div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ تواصل معنا ـــــــ
                        <p>
                            <?php echo e($sections->about); ?>

                        </p>
                        <div class="navegation">
                            <li>
                                <a href="index.html">
                                    <span class="fa fa-home"></span>
                                </a>
                            </li>
                            | تواصل معنا
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact-us-content">
            <div class="container">
                <div class="row">
                    <h3>
                        <span class="glyphicon glyphicon-user"></span>
                      إملئ البيانات التالية
                    </h3>
                    <div class="col-lg-7 col-md-6 col-sm-12">
                        <div class="form-body">
                            <form>
                                <div class="form-group">
                                    <input type="text" placeholder="الأسم" class="form-control" required>
                                    <input type="text" placeholder="رقم التليفون" class="form-control" required>
                                    <input type="text" placeholder="البريد الألكترونى" class="form-control" required>
                                    <textarea class="form-control" placeholder="الرسالة" style="height:120px;"></textarea>
                                    <button class="btn btn-default">إرسـال</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <div class="contact-address">
                            <span class="flaticon-map-with-position-marker"></span>
                            <h1>
                                ميدان شرف - شبين الكوم  - المنوفية
                            </h1>
                        </div>
                        <div class="contact-address">
                            <span class="fa fa-envelope-o"></span>
                            <h1 id="spec-font">
                               <?php echo e($sections->email); ?>

                            </h1>
                        </div>
                        <div class="contact-address">
                            <span class="fa fa-volume-control-phone"></span>
                            <h1>
                                <?php echo e($sections->mobile); ?>

                            </h1>
                        </div>
                        <div class="contact-address">
                            <span class="fa fa-volume-control-phone"></span>
                            <h1>
                               <?php echo e($sections->phone); ?>

                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13742.584709302486!2d31.018553676645308!3d30.559299184537192!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f7d68d460edbf9%3A0x971fc377ba731aa4!2z2YXZitiv2KfZhiDYtNix2YHYjCDZgtiz2YUg2LTYqNmK2YYg2KfZhNmD2YjZhdiMINi02KjZitmGINin2YTZg9mI2YXYjCDYp9mE2YXZhtmI2YHZitip!5e0!3m2!1sar!2seg!4v1453805094132" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen>
                </iframe>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>