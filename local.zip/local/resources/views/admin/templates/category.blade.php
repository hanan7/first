<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label for="sub_cat" class="control-label">اضافة صنف فرعي</label>
            <input type="text" id="sub_cat" name="sub_cat[]" class="form-control " >
            <button type="button" class="new-sub-cat btn btn blue-soft"><li class="fa fa-plus-circle"></li></button>
            <button type="button" class="del-sub-cat btn btn red-soft"><li class="fa fa-minus-circle"></li></button>
        </div>
    </div>
</div>