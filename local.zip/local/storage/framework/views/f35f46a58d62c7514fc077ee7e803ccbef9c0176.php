<?php $__env->startSection("title"); ?>
المنتجات
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
 <h1 class="page-title"> اداره المنتجات</h1>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
      <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">الدكاكين</a>
     <i class="fa fa-angle-left"></i> 
 </li>
 <li>
   <a href="#">عرض المنتجات</a>
 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                 
<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

<!-- BEGIN CONTAINER -->
     
<!-- BEGIN CONTENT -->
          
<div class="row">
    <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                
                                
                          <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-eye"></i>عرض المنتجات </div>
                                
                                </div>
                                
                                
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                               
                                            </div>
                                            <div class="col-md-6">
                                                <div class="btn-group pull-right">
                                                    <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">الادوات
                                                        <i class="fa fa-angle-down"></i>
                                                    </button>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-print"></i> طباعه  </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-pdf-o"></i> حفظ ك  PDF </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-excel-o"></i> تصدير الى  Excel </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="well table-toolbar ">
                                    <form id="searchform" method="get">
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group">
                                                <label class="control-label bold">اسم المنتج</label>
                                               <input type="text" name="name" id="name" class="form-control">
                                                </div>
                                            </div> 
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group">
                                                <label class="control-label bold">القسم</label>
                                                <select ame="filter_order_status_id" id="input-status" name="input-status" class=" form-control">
                                               <?php foreach($cate as $cat): ?>
                                                    <option value="0"> <?php echo e($cat->cat_trans('ar')->name); ?></option>
                                                    <?php endforeach; ?>
                                                  
                                                </select>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                        <div class="row">    
                                            <div class="col-md-6 col-sm-6">
                                               
                                                <button type="button" id="filter" class="btn green">
                                                   <li class="fa fa-search"></li> بحث
                                                </button>
                                               
                                            </div> 
                                        </div>  
                                        </form>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th class="text-center"> اسم المنتج</th>
                                                <th class="text-center" width="20%"> السعر:</th>
                                                <th class="text-center" width="20%">  الموديل:</th>
                                                <th class="text-center"> اسم الدكان</th>
                                                  <th class="text-center">الصوره</th>
                                                 <th class="text-center"> عمليات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($sections as $section): ?>
                                          <tr class="odd gradeX">
                                                <td class="text-center"><?php echo e($section->product_trans('ar')->name); ?></td>
                                                <td class="text-center"><?php echo e($section->price); ?></td>
                                                <td class="text-center"><?php echo e($section->model); ?></td>
                                                <td class="text-center"><?php echo e($section->price); ?></td>
                                                <td class="text-center">
                                                    <img src="<?php echo e(URL("uploads/".$section->image."")); ?>" style="width:100px;">
                                                </td>
                                                <td class="text-center">
                                               
                                                <a href="<?php echo e(url('products/'.'delete/'.$section->id)); ?>"  data-toggle="modal" title=""
                                                 class="btn red  btn_show" data-original="">
                                                  <li class="fa fa-trash "> حذف </li>

                                                </a>
                               
                                                </td>
                                                
                                            </tr>
                                            <?php endforeach; ?>
                                      
                                        </tbody>
                                    </table>    
                                    
                                    <div id="reloaddiv">
                                        <div id="searchlist"></div>
                                      </div>

                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                

   
<!-- END CONTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
  
<script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-level-script'); ?>
 
<script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript"></script>    
       
<?php $__env->stopSection(); ?>




<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>