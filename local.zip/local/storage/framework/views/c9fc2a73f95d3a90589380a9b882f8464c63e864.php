<?php $__env->startSection('title'); ?>
الاقسام
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layoutscripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('levelscripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title"> الاقسام
   
    </h3>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
    <li>
   	 	<i class="icon-home"></i>
    	<a href="index.html">الصفحة الرئيسية</a>
    	<i class="fa fa-angle-left"></i>
    </li>
    <li>
       	<a href="#">تعديل قسم</a>
    </li>                   
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
  <?php endif; ?>
        <div class="row">
    <div class="col-md-12">
            <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
                <div class="portlet box green">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-pencil"></i>تعديل قسم
                        </div>
                    </div>

                    <div  class="portlet-body form">
                            <form method="post" name="settingform"   id="settingform" class="horizontal-form">
                                <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <div class="form-body">
                                        <h3 class="form-section">تعديل قسم</h3>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">اسم القسم<span style="color:red;">*</span></label>
                                                    <ul class="nav nav-tabs">
                                                        <li class="active ">
                                                        <a href="#tab_1" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                                        </a>
                                                        </li>
                                                        <li>
                                                        <a href="#tab_2" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags\gb.png')); ?>">
                                                        </a>
                                                        </li>
                                                    </ul>
                                                    <div class="tab-content">
                                                        <div class="tab-pane fade active in" id="tab_1">
                                                            <div class=" input-icon right">       
                                                                <input type="text" id="ar_name" name="ar_name" value="" class="form-control required" >
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="tab_2">
                                                            <div class=" input-icon right"> 
                                                                <input type="text" id="en_name" name="en_name"  class="form-control " >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">نوع القسم <span style="color:red;">*</span></label>
                                                    <ul class="nav nav-tabs">
                                                        <li class="active ">
                                                        <a href="#tab_1" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                                        </a>
                                                        </li>
                                                        <li>
                                                        <a href="#tab_2" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags/gb.png')); ?>">
                                                        </a>
                                                        </li>
                                                    </ul>
                                                    <div class="tab-content">
                                                        <div class="tab-pane fade active in" id="tab_1">
                                                            <div class=" input-icon right">       
                                                                <input type="text" id="ar_name" name="ar_name" value="" class="form-control required" >
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="tab_2">
                                                            <div class=" input-icon right"> 
                                                                <input type="text" id="en_name" name="en_name"  class="form-control " >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>                                                      
                                        </div>
                            
                                        
                                        <hr />
                                        <h3 class="form-section">معلومات SEO</h3> 
                                        <div class="row">  
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">مفتاح ال Meta</label>
                                                    <ul class="nav nav-tabs">
                                                        <li class="active ">
                                                        <a href="#tab_1" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags/eg.png')); ?>">
                                                        </a>
                                                        </li>
                                                        <li>
                                                        <a href="#tab_2" data-toggle="tab" aria-expanded="true">    <img src="<?php echo e(asset('assets/admin/global/img/flags\gb.png')); ?>">
                                                        </a>
                                                        </li>
                                                    </ul>
                                                    <div class="tab-content">
                                                        <div class="tab-pane fade active in" id="tab_1">
                                                            <div class=" input-icon right">       
                                                                <input type="text" id="ar_name" name="ar_name" value="" class="form-control required" >
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="tab_2">
                                                            <div class=" input-icon right"> 
                                                                <input type="text" id="en_name" name="en_name"  class="form-control " >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>  
                                   
                                    </div>            
                                    <div class="form-actions">
                                        <div class="col-md-12 text-center" >
                                            <button type="button" class="btn green btn_save">
                                                <i class="fa fa-check"></i> حفظ</button>
                                            <button type="button" class="btn default btn_save">
                                                <i class="fa fa-times"></i> الغاء</button> 
                                        </div>      
                                    </div>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>  



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>