  <div class="top-content">
        <div class="container-fluid">
            <div class="row">
                <div class="side-menu">
                    <nav class="navbar navbar-default" role="navigation">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <div class="brand-wrapper">
                                <!-- Hamburger -->
                                <button type="button" class="navbar-toggle">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            <!-- Brand -->
                <div class="brand-name-wrapper" id="pr">
                    <span class="navbar-brand"><span class="fa fa-bars"></span>الدكاكيــن</span></div>
            </div><!-- end brand-wrapper -->
                    </div><!-- end navbar-header -->
                    
                    <!-- Main Menu -->
                    <div class="side-menu-container">
                        <ul class="nav navbar-nav" id="do">
                            <?php $a=0;?>
                                <?php foreach($main as $maincate): ?>
                                <?php $a=$a+1; ?>
                                <li class="dropdown">
                                    <a href="<?php echo e(url('category/'.$maincate->cat_trans('ar')->id)); ?>" class="dropbtn">
                                        <span class="fa fa-arrow-circle-o-left"></span> <?php echo e($maincate->cat_trans('ar')->name); ?>

                                    </a>
                                    <div class="dropdown-content" id="d<?php echo e($a); ?>">
                                            <?php if(!$maincate->subcat->isEmpty()): ?>
                                            <?php foreach($maincate->subcat as $sub1): ?>
                                            <?php if(!empty($sub1->cat_trans('ar'))): ?>
                                                                                    <div class="first-cats">

                                            <header><?php echo e($sub1->cat_trans('ar')->name); ?></header>
                                            <ul>
                                                <?php if(!$maincate->subcat->isEmpty()): ?>
                                                <?php foreach($sub1->subcat as $sub2): ?>
                                                <?php if(!empty($sub2->cat_trans('ar'))): ?>
                                                <li>
                                                    <i class="fa fa-arrow-circle-o-left"></i><a href="<?php echo e(URL('category/'.$sub2->cat_trans('ar')->id)); ?>"><?php echo e($sub2->cat_trans('ar')->name); ?></a> </li>
                                                
                                            <?php endif; ?>
                                            <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                                                             <?php endif; ?>

                                        <?php endforeach; ?>
                                       
                                    <?php endif; ?>
                                </li>                                    <?php endforeach; ?>
                        </ul>
                        </div>
                        <!-- /.navbar-collapse -->
                    </nav>
                </div>
              <?php echo $__env->yieldContent('slider'); ?>
            </div>
        </div>
    </div>