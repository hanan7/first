<?php $__env->startSection("title"); ?>
الاعدادات العامة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
 <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">الاعدادات العامة</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">الاعدادات العامة</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                 
<?php $__env->startSection('content'); ?>
 
<div id="profile" class="instaFade">
	<div class="mainDetails"> 
		<div id="headshot" class="quickFade">
			<img src="<?php echo e(url('uploads/admins/'.$admin->photo)); ?>" alt="<?php echo e($admin->name); ?>" />
		</div>
		
		<div id="name">
			<h1 class="quickFade delayTwo"><?php echo e($admin->name); ?></h1>
			
		</div>
		
		
		<div class="clear"></div>
	</div>
	
	<div id="mainArea" class="quickFade delayFive">
		<section>
			<article>
				<div class="sectionTitle">
					<h1>الاسم</h1>
				</div>
				
				<div class="sectionContent">
					<p><?php echo e($admin->name); ?></p>
				</div>
			</article>
			<div class="clear"></div>
		</section>
		
		 <section>
			<article>
				<div class="sectionTitle">
					<h1>الاسم المستخدم</h1>
				</div>
				
				<div class="sectionContent">
					<p><?php echo e($admin->username); ?></p>
				</div>
			</article>
			<div class="clear"></div>
		</section>

		 <section>
			<article>
				<div class="sectionTitle">
					<h1>الايميل</h1>
				</div>
				
				<div class="sectionContent">
					<p><?php echo e($admin->email); ?></p>
				</div>
			</article>
			<div class="clear"></div>
		</section>

        
        
         <section>
			<article>
				<div class="sectionTitle">
					<h1>العنوان</h1>
				</div>
				
				<div class="sectionContent">
					<p><?php echo e($admin->address); ?></p>
				</div>
			</article>
			<div class="clear"></div>
		</section>
		
        
        <section>
			<article>
				<div class="sectionTitle">
					<h1>التليفون</h1>
				</div>
				
				<div class="sectionContent">
					<p><?php echo e($admin->address); ?></p>
				</div>
			</article>
			<div class="clear"></div>
		</section>
        
        
		<section>
			<div class="sectionTitle">
				<h1>معلومات اضافية</h1>
			</div>
			
			<div class="sectionContent">
				<article>
					<?php echo e($admin->other); ?>

				</article>
				
			</div>
			<div class="clear"></div>
		</section>
		
		
		
		
		
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>