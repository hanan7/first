<?php $__env->startSection("title"); ?>
    المنتجات
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
    <link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>"
          rel="stylesheet" type="text/css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
    <h3 class="page-title">المنتجات</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
    <ul class="page-breadcrumb">
        <li>
            <i class="icon-home"></i>
            <a href="<?php echo e(url('/admin')); ?>">الصفحة الرئيسية</a>
            <i class="fa fa-angle-left"></i>
        </li>
        <li>
            <a href="#">المنتجات</a>


        </li>

    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('success')): ?>
        <?php
        $a = [];
        $a = session()->pull('success');
        ?>
        <div class="alert alert-success alert-dismissable">
            <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
            <?php echo e($a[0]); ?>


        </div>
    <?php endif; ?>
    <?php if(session()->has('danger')): ?>
        <?php
        $a = [];
        $a = session()->pull('danger');
        ?>
        <div class="alert alert-warrning alert-dismissable">
            <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
            <?php echo e($a[0]); ?>


        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
                <div class="portlet box blue">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-pencil"></i>
                            تعديل منتج
                        </div>
                    </div>

                    <div class="portlet-body form">
                        <form method="post" name="settingform" action="<?php echo e(URL('products/edit/'.$old->id)); ?>"
                              id="settingform" class="horizontal-form" files="true" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            <div class="form-body">
                                <h3 class="form-section">تعديل منتج</h3>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">كود المنتج</label>
                                            <input type="number" id="code" name="code" class="form-control"
                                                   value="<?php echo e($old->code); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">اسم المنتج</label>
                                            <input type="text" id="name" name="name" class="form-control "
                                                   value="<?php echo e($old->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">الشركة الموردة</label>
                                            <input type="text" id="company" name="company" class="form-control"
                                                   value="<?php echo e($old->company); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">نقاط المبيعات</label>
                                            <input type="number" id="points" name="points" min="0" class="form-control"
                                                   value="<?php echo e($old->points); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">نقاط المرتجع</label>
                                            <input type="number" id="points" min="0" name="dmg_points"
                                                   class="form-control"
                                                   value="<?php echo e($old->dmg_points); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">الكمية</label>
                                            <input type="number" id="quantity" name="quantity" min="0"
                                                   class="form-control " value="<?php echo e($old->quantity); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label">عدد الكراتين</label>
                                            <input type="number" id="box-count" min='1' value="<?php echo e($old->box_count); ?>"
                                                   name="box_count" class="form-control ">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label ">عدد القطع داخل كل كرتونه</label>
                                            <input type="number" id="box-items-count" min='1'
                                                   value="<?php echo e($old->box_items_count); ?>" name="box_items_count"
                                                   class="form-control ">
                                        </div>
                                    </div>
                                    <div class="col-md-4 text-left">
                                        <div class="form-group" style="line-height: 85px;">
                                            = <span id="box-total"><?php echo e($old->box_total); ?></span>&nbsp;قطعه
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">سعر الشراء</label>
                                            <input type="text" id="b_price" min="0" name="b_price" class="form-control"
                                                   value="<?php echo e($old->b_price); ?>">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">سعر البيع</label>
                                            <input type="text" id="s_price" name="s_price" min="0" class="form-control"
                                                   value="<?php echo e($old->s_price); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">اسم المخزن</label>
                                            <select class="form-control" name="store">
                                                <?php foreach($store as $store): ?>
                                                    <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">اسم الصنف</label>
                                            <select class="form-control text-capitalize" name="sub_cat_id">
                                                <?php foreach($sub_cats as $sub_cat): ?>
                                                    <option value="<?php echo e($sub_cat->id); ?>"><?php echo e($sub_cat->category->name . ' >>> ' . $sub_cat->name); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">الوصف</label>
                                            <textarea id="desc" name="desc"
                                                      class="form-control"><?php echo e($old->desc); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">الصورة</label>
                                            <input type="file" id="image" name="image" class="form-control ">
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="form-actions">
                                <div class="col-md-12 text-center">
                                    <button type="submit" name="submit" class="btn green btn_save">
                                        <i class="fa fa-pencil"></i> تعديل
                                    </button>
                                    <a href="<?php echo e(url('products/all-products')); ?>" type="button"
                                       class="btn default btn_save">
                                        <i class="fa fa-times"></i> الغاء</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>                     
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>