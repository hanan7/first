<?php $__env->startSection("title"); ?>
العملاء
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-title"); ?>
 <h1 class="page-title">العملاء</h1>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">العملاء</a>
  
 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                              
<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

<!-- BEGIN CONTAINER -->
     
            <!-- BEGIN CONTENT -->
<meta name="_token" content="<?php echo e(csrf_token()); ?>">   
<div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                
                                
                          <div class="portlet-title">

                                    <div class="caption">
                                        <i class="fa fa-eye"></i>عرض العملاء </div>
                                
                                </div>
                                
                                
                                <div class="portlet-body">
                                 <div  class="alert alert-danger display-none">
                                      <ul>
                                          
                                          <li>
                                              لم يتم ادخال البيانات بشكل صحيح 
                                          </li>
                                          
                                      </ul>
                                  </div>
                                    <div class="table-toolbar">
                                        <div class="row">
                                          <div class="col-md-6">
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('customers/customer')); ?>" class="btn btn green" data-toggle="modal"> 
                                                        <i class="fa fa-plus"></i>
                                                        اضافة عميل 
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="btn-group pull-right">
                                                    <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">الادوات
                                                        <i class="fa fa-angle-down"></i>
                                                    </button>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-print"></i> طباعه  </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-pdf-o"></i> حفظ ك  PDF </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-excel-o"></i> تصدير الى  Excel </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="well table-toolbar ">
                                     <form method="get" id="search_form" action="<?php echo e(url('customers/search')); ?>">
                                    
                                        <div class="row">
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">اسم العميل</label>
                                                <input type="search" name="name" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">اسم المحل</label>
                                                <input type="search" name="add_date" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">الايميل</label>
                                                <input type="search" name="email" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="form-group">
                                                <label class="control-label bold">البلد</label>
                                                <input type="search"  name="country" autocomplete="on" class="form-control input large input-large input-inline" aria-controls="sample">
                                                </div>
                                            </div>
                                        </div>    
                                        <div class="row">    
                                            <div class="col-md-4 col-sm-4">
                                               
                                                <button type="button" id="filterBtn" class="btn green demo-loading-btn">
                                                   <li class="fa fa-search"></li> بحث
                                                </button>
                                               
                                            </div> 
                                        </div>
                                        </form>
                                        </div> 
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr> 
  
                                                <th class="text-center"> اسم العميل </th>
                                                <th class="text-center"> التليفون </th>
                                                <th class="text-center"> الايميل </th>
                                                <th class="text-center"> اسم المحل</th>
                                                <th class="text-center"> البلد</th>
                                                <th class="text-center"> العمليات</th>
                                            </tr>
                                        </thead> 
                                        <tbody>
                                            <?php foreach($sections as $section): ?>

                                            <tr class="odd gradeX">
                                                <td class="text-center"><?php echo e($section->name); ?></td>
                                                <td class="text-center"><?php echo e($section->phone); ?></td>
                                                <td class="text-center"><?php echo e($section->email); ?></td>
                                                <td class="text-center"><?php echo e($section->dokan); ?></td>
                                                <td class="text-center"><?php echo e($section->country); ?></td>
                                                <td class="text-center">
                                               
                                                <a href="<?php echo e(url('customers/'.'delete/'.$section->id)); ?>"  data-toggle="modal" title=""
                                                 class="btn red  btn_show" data-original="">
                                                  <li class="fa fa-trash "> حذف </li>

                                                </a>
                                                 <a href="<?php echo e(url('customers/'.'edit/'.$section->id)); ?>"  data-toggle="modal" title=""
                                                 class="btn green update" data-original="">
                                                  <li class="fa fa-pencil ">  تعديل </li>

                                                </a>
                                                </td>
                                                
                                            </tr>
                                            <?php endforeach; ?>
                                            
                                        
                                        </tbody>
                                        
                                    </table>
     
                                    
       
                                   
                      </div>
                      <div id="reloaddiv">
                    <div id="productsChildList"></div>
                  </div>
                                </div>
                       
                            </div>

                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                
<!--Model--> 

<div id="viewcustomer"></div>


       
<!-- END CONTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
 
<script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-level-script'); ?>
<script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript"></script>        
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>