<?php $__env->startSection('content'); ?> 
    <div id="wrap">
        <div class="section-title">
            <div class="container-fluid over">
                <div class="row">
                    <div class="sce-det">
                        ـــــــ إحجز مع المضيف الأن ـــــــ
                    </div>
                    <div class="wizard">
                        <div class="wizard-inner">
                            <div class="connecting-line"></div>
                            <ul class="nav nav-tabs" role="tablist">

                                <li role="presentation" class="active">
                                    <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-user"></i>
                            </span>
                                        <p>
                                            البيانات الشخصية
                                        </p>
                                    </a>
                                </li>

                                <li role="presentation" class="disabled">
                                    <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-plane"></i>
                            </span>
                                        <p>
                                            بيانات الحجز
                                        </p>
                                    </a>
                                </li>

                                <li role="presentation" class="disabled">
                                    <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-thumbs-up"></i>
                            </span>
                                        <p>
                                            إنهاء
                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container">
                <div class="row">
                    <form role="form" action="<?php echo e(url('hotel/book-hotel')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="tab-content">
                            <div class="tab-pane active" role="tabpanel" id="step1">
                                <h3>
                                    <span class="glyphicon glyphicon-user"></span>
                                    البيانات الشخصية
                                </h3>
                                <div class="col-lg-8 col-md-8 col-sm-12">
                                    <div class="form-body">
                                        <form>
                                            <div class="form-group">
                                                <input type="text" placeholder="الأسم" name="name" class="form-control" required>
                                                <input type="text" placeholder="رقم التليفون"  name="phone" class="form-control" required>
                                                <input type="text" placeholder="البريد الألكترونى" name="email" class="form-control" required>
                                                <input type="text" placeholder="العنوان" name="address" class="form-control" required>
                                            </div>    
                                        </form>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="serv">
                                        <span class="flaticon-man-travelling"></span>
                                        <h1>
                                            <i>+ <?php echo e($sections->agents_num); ?></i>
                                            عميل
                                        </h1>
                                        <p>
                                            <?php echo e($sections->agents_desc); ?>

                                        </p>
                                    </div>
                                </div>
                                <ul class="list-inline">
                                    <li>
                                        <button type="button" class="btn btn-primary next-step">حفظ ومتابعة</button>
                                    </li>
                                </ul>

                            </div>
                            <div class="tab-pane" role="tabpanel" id="step2">
                                <h3>
                                    <span class="glyphicon glyphicon-plane"></span>
                                    بيانات الحجز
                                </h3>
                                <div class="col-lg-8 col-md-8 col-sm-12">
                                    <div class="form-body">
                                        
                                            <div class="form-group">
                                                <input type="text" id="datepicker" placeholder="من" name="start_date" class="form-control" required>
                                                <input type="text" id="datepicker-2" placeholder="إلى" name="end_date" class="form-control" required>
                                                <input type="text" placeholder="عدد الافراد" name="agents_num" class="form-control">
                                                    
                                                <input type="text" placeholder="عدد الاطفال" name="children" class="form-control">
                                            </div>
                                        
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="serv">
                                        <span class="flaticon-map-with-position-marker"></span>
                                        <h1>
                                           <i>+ <?php echo e($sections->trips_num); ?></i>
                                           رحلة سياحية
                                        </h1>
                                        <p>
                                           <?php echo e($sections->trips_desc); ?>

                                        </p>
                                    </div>
                                </div>
                               
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="serv">
                                        <span class="flaticon-24-hours-support"></span>
                                        <h1>
                                             <i>24</i>
                                            ساعة خدمة عملاء
                                        </h1>
                                        <p>
                                            هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما
                                        </p>
                                    </div>
                                </div>
                                <ul class="list-inline ">
                                    <li>
                                        <button type="button" class="btn btn-default prev-step">رجوع</button>
                                    </li>
                                    <li>
                                        <button type="submit" name="submit" class="btn btn-primary next-step">حفظ ومتابعة</button>
                                    </li>
                                </ul>
                            </div>
                    </form>        
                            <div class="tab-pane" role="tabpanel" id="complete">
                                <span class="fa fa-thumbs-o-up"></span>
                                <h1>تمت عملية الحجز بنجاح</h1>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>