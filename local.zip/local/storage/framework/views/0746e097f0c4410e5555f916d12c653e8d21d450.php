<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(URL('assets/front/images/fav-icon.png')); ?>" rel='icon' type='image/x-icon' />
    <!-- include css files -->
    <link rel="stylesheet" href="<?php echo e(URL('assets/front/css/nivo-slider.css')); ?>" type="text/css" media="screen" />
     
    <script language="javascript" type="text/javascript">
        function clearText(field)
        {
        if (field.defaultValue == field.value) field.value = '';
        else if (field.value == '') field.value = field.defaultValue;
        }
    </script>

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/tooplate_style.css')); ?>" />

    <title>سهل للتجارة والتوزيع</title>

    <style>
         html,body{height:100%; margin:0px;} 
    </style> 
</head>

<body style="background-color:#dddddd;"  class="homepage">
<!-- Start Header -->
<?php echo $__env->make('front.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- End Header -->
<div class="clear"></div>
<!-- Start Wrap -->
    <?php echo $__env->yieldContent('content'); ?>
<!-- End Wrap -->
<div class="clear"></div>

<!-- Start Footer -->
<?php echo $__env->make('front.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- End Footer -->
    <!-- includ js files -->
    <script src="<?php echo e(URL('assets/front/js/jquery.js')); ?>"></script>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <script src="<?php echo e(URL('assets/front/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/custom.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL('assets/front/sliderengine/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL('assets/front/sliderengine/jquery.hislider.js')); ?>"></script>
    <script language="javascript" type="text/javascript">
        function clearText(field)
        {
          if (field.defaultValue == field.value) field.value = '';
          else if (field.value == '') field.value = field.defaultValue;
        }
    </script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo e(URL('assets/front/js/jquery.nivo.slider.js')); ?>" type="text/javascript"></script>

    <script type="text/javascript">
    $(window).load(function() {
    $('#slider').nivoSlider({
        effect:'random',
        slices:10,
        animSpeed:500,
        pauseTime:2200,
        startSlide:0, //Set starting Slide (0 index)
        directionNav:false,
        directionNavHide:false, //Only show on hover
        controlNav:false, //1,2,3...
        controlNavThumbs:false, //Use thumbnails for Control Nav
        pauseOnHover:true, //Stop animation while hovering
        manualAdvance:false, //Force manual transitions
        captionOpacity:0.8, //Universal caption opacity
        beforeChange: function(){},
        afterChange: function(){},
        slideshowEnd: function(){} //Triggers after all slides have been shown
    });
});
</script>
 
</body>

</html>     