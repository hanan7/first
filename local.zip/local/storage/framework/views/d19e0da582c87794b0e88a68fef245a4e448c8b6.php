<footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 about-us">

                    <div class="logo">
                        <img src="<?php echo e(URL('assets/front/images/logo-w.png')); ?>">
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 useful-link">
                    <div class="sec-tit">
                        <h1>
                          لينكات سريعة
                        </h1>
                        <hr>
                    </div>
                    <ul>
                        <li>
                            <a href="#">
                                الرئيسية              
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                الحجز
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               عن الشركة
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                تواصل معنا
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                 رحلات سياحية
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                حج وعمرة
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               تذاكر طيران
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               أماكن تاريخية
                            </a>
                        </li>
                    </ul>

                </div>

                <div class="col-lg-4 col-md-4 col-sm-12 quick-contact">
                    <div class="sec-tit">
                        <h1>
                            تواصل معنا
                        </h1>
                        <hr>
                    </div>
                    <div class="contact">
                        <p>
                            <span class="fa fa-map-marker"></span> ميدان شرف / شبين الكوم / المنوفية
                        </p>
                        <hr>
                        <p>
                            <span class="fa fa-volume-control-phone"></span> إتصل بنا 01090353855
                        </p>
                        <hr>
                        <p>
                            <span class="fa fa-envelope-o"></span>
                            <i>info@hgamal.com
                            </i>
                        </p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 copy-right">
                    <hr>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <p>
                            جميع الحقوق محفوظة © 2015
                            <i>
                            المضيف
                            </i> | بواسطة
                            <span>
                           بن الميدان
                            </span>
                        </p>

                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 scoial">
                        <span class="fa fa-facebook"></span>
                        <span class="fa fa-twitter"></span>
                        <span class="fa fa-google-plus"></span>
                        <span class="fa fa-linkedin"></span>
                    </div>
                </div>

            </div>
        </div>
    </footer> 