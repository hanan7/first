<?php $__env->startSection("title"); ?>
المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection("styles"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
    rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />              
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">المخازن</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">المخازن</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
 <?php if(session()->has('success')): ?>
 <?php $a=[];
 $a = session()->pull('success');
 ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
 <?php if(session()->has('danger')): ?>
 <?php $a=[];
 $a = session()->pull('danger');
 ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
     <?php echo e($a[0]); ?>

    
    </div>
 <?php endif; ?>
  	<div class="portlet box blue">
    <div class="portlet-title">
        <div class="caption">
          <i class="fa fa-eye"></i> جرد</div>
    </div>

    <div class="portlet-body" >
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                
              </div>
            </div>
           
          </div>
        </div>  

      <?php if(count($storeGoods)): ?>
         <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th class="text-center"> اسم المنتج  </th>
                <th class="text-center"> الكمية</th>
                
                
              </tr>
            </thead>
             
            <tbody>
          <?php foreach($storeGoods as $str): ?>
              <tr>
                   
                    <td class="text-center"> <?php echo e($str->name); ?> </td>
                    <td class="text-center"> <?php echo e($str->quantity); ?> </td>
                   
              </tr>
          <?php endforeach; ?> 

            </tbody>

          </table>
            <div class="text-right">
                             
                              <a href="<?php echo e(url('stores/all-stores')); ?>" type="button" class="btn default btn_save">
                              <i class="fa fa-times"></i> الغاء</a> 
                            </div>

    <?php else: ?>
    <div class="alert alert-info"> لا يوجد بضائع بهذا المخزن</div>
      <?php endif; ?>

       
    </div>
  
</div>
   <?php echo $__env->make('admin.pages.stores.addstore', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection("layoutscripts"); ?>
        ><script src="<?php echo e(asset('assets/admin/global/scripts/datatable.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>" type="text/javascript"></script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection("levelscripts"); ?>
 <script src="<?php echo e(asset('assets/admin/pages/scripts/table-datatables-managed.min.js')); ?>" type="text/javascript">
 	
 </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>