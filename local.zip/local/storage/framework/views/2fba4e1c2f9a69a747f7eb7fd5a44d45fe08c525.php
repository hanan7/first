<header>
        <div class="container-fluid">
            <div class="row">
                <div class="top-header">
                    <div class="scoial">
                        <a href="">
                            <span class="fa fa-facebook s"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-twitter"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-snapchat-ghost"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-google-plus"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-linkedin"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-youtube"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-instagram"></span>
                        </a>
                        <a href="">
                            <span class="fa fa-whatsapp"></span>
                        </a>
                    </div>
                    <div class="top-link">
                       <?php if(auth()->check()): ?>
                        <li>
                            <a href="profile">
                                <i class="fa fa-user"></i> <?php echo e(auth()->user()->name); ?>

                            </a>
                           
                        </li>
                        <li> <a class="fa fa-lock" href="logout"></a>خروج</li>
                        <?php else: ?>
                        <li class="lo">
                            <a href="login">
                                <i class="fa fa-lock"></i> دخـول
                            </a>
                        </li>
                        <li class="re">
                            <a href="register">
                                <i class="fa fa-sign-in"></i> تسجيل جديـد
                            </a>
                        </li>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="bottom-header">
                    <div class="logo">
                        <img src="<?php echo e(URL('assets/front/images/logo.png')); ?>">
                    </div>
                    <div class="search">
                        <form action="" method="" role="">
                            <input class="form-control" type="text" value="" placeholder="إبحث عن المنتج">
                            <button class="btn btn-default" type="submit">
                                <span class="fa fa-search"></span>
                            </button>
                        </form>
                    </div>
                    <div class="other-link">
                        <a href="#">
                            <button class="btn btn-default" type="button">
                                <span class="fa fa-apple"></span>
                            </button>
                        </a>
                        <a href="#">
                            <button class="btn btn-default" type="button">
                                <span class="fa fa-android"></span>
                            </button>
                        </a>
                        <div class="shop-icon">
                            <div class="cart">
                                <i class="fa fa-shopping-cart"></i>
                                <span> 3 </span>
                            </div>
                            <div class="cart-content">
                                <div class="prod-cart">
                                    <img src="<?php echo e(URL('assets/front/images/cart-1.jpg')); ?>">
                                    <h5>ساعة  فضية</h5>
                                    <p> x3 </p>
                                    <h6>100$</h6>
                                    <span class="fa fa-trash-o"></span>
                                </div>
                                <div class="prod-cart">
                                    <img src="<?php echo e(URL('assets/front/images/cart-2.jpg')); ?>">
                                    <h5>موبيل سمارت</h5>
                                    <p> x3 </p>
                                    <h6>300$</h6>
                                    <span class="fa fa-trash-o"></span>
                                </div>
                                <div class="prod-cart">
                                    <img src="<?php echo e(URL('assets/front/images/cart-1.jpg')); ?>">
                                    <h5>ساعة  فضية</h5>
                                    <p> x3 </p>
                                    <h6>100$</h6>
                                    <span class="fa fa-trash-o"></span>
                                </div>
                                <h2>الإجمالـى : <i>400.00 </i> دولار</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="menu">
                    <ul>
                        <li>
                            <a href="index.html">
                                <i class="fa fa-home"></i> الرئيسية
                            </a>
                        </li>
                        <li>
                            <a href="offer.html">
                                <i class="fa fa-bullhorn"></i> سوق الجمعة
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa fa-tags"></i> كتالوجات
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa fa-gift"></i> دانات دكان
                            </a>
                        </li>
                        <li>
                            <a href="blogs.html">
                                <i class="fa fa-newspaper-o"></i> الأنشطة
                            </a>
                        </li>

                        <li>
                            <a href="contact.html">
                                <i class="fa fa-envelope-o"></i> تواصل معنا
                            </a>
                        </li>
                    </ul>
                    <div class="ma-off">
                        <a href="add-offer.html" class="make-offer">
                            <button class="btn btn-default">
                                <span class="fa fa-bullhorn"></span> أضـف إعلان
                            </button>
                        </a>
                        <a href="#" class="build">
                            <button class="btn btn-default">
                                <span class="fa fa-plus"></span> إنشا دكان
                            </button>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </header>