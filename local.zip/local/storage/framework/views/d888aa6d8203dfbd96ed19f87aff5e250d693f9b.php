<script type="text/javascript">
    $(".btnedit1").click(function(){
    
    var id  = <?php echo e($all->id); ?>

    var form12 = document.forms.namedItem("updateform");
    var data = new FormData(form12);
   $.ajax({
      url:"<?php echo e(url('attributes/edit')); ?>"+"/"+id,
      type:'post',
      headers: {
        'X-CSRF-Token': $('meta[name="_token"]').attr('content')
      },
      processData:false,
      data:data,
      contentType:false,
      beforeSend: function(){
              $("#loadmodel").show();
      },
     success: function( data ) {
              window.location.reload(); 
                },
      error:function(data){
         $("#loadmodel").remove();
        $(".dele").remove();
       $(".alert-danger").show();
       
      },
    });
});
</script>


<!--<script type="text/javascript">
  
   $(".btndelete").click(function(){
    var id  = <?php echo e($all->id); ?>

    //dd(id);
   $.ajax({
      url:"<?php echo e(url('attributes/delete')); ?>"+"/"+id,
      type:'post',
      headers: {
        'X-CSRF-Token': $('meta[name="_token"]').attr('content')
      },
      beforeSend: function(){
              $("#loadmodel").show();
      },
      success: function(data){
      
       window.location.reload();
       // $(".alert-danger").remove();
       //  $(".alert-success").show();
      },
      error:function(data){
        $(".dele").remove();
        //$(".alert-danger").show();
      },
    });
});
</script>  -->