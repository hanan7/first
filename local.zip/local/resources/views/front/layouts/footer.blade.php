 <footer>
        <div class="copyright text-center">
            Copyright &copy; 2016 <span><a href="#" target="_blank">ذكاء للبرمجيات</a></span>
        </div>
    </footer>