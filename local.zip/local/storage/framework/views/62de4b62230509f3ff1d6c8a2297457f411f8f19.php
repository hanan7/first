<!DOCTYPE html>
<html ng-app="app">

<head>
    <meta charset="UTF-8">
    <meta name="_token" content="<?php echo csrf_token(); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo e(URL('assets/front/images/fav-icon.png')); ?>" rel='icon' type="image/x-icon"/>
    <!-- ================================== include CSS files ======================================= -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/rtl.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/font-awesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL('assets/front/js/layerslider/css/layerslider.css')); ?>">
        <script src="<?php echo e(URL('assets/front/js/angular.min.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/angular-messages.min.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/app.js')); ?>"></script>

    <?php echo $__env->yieldContent('style'); ?>
    <!-- ================================== include CSS files ======================================= -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>

    
    <!--========================================  Start Header ========================================-->
    <?php echo $__env->make('front.layouts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--========================================  End Header ========================================-->
    <div class="clear"></div>
    <!--========================================  Start Content ========================================-->
    <!--======= Start top-content ( sid-menu / slider)=======-->
  <?php echo $__env->make('front.layouts._sidemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="clear"></div>
  <!--================== Start Features ==========================-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--========================================  Start Subscrib   ========================================-->
      <div class="clear"></div>
    <?php echo $__env->make('front.layouts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- ================================== include JS files ======================================= -->

    <script src="<?php echo e(URL('assets/front/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/layerslider/js/greensock.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/layerslider/js/layerslider.transitions.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/layerslider/js/layerslider.kreaturamedia.jquery.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/nicescroll.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/countdown.js')); ?>"></script>
    <script src="<?php echo e(URL('assets/front/js/bootstrap.js')); ?>"></script>
<<<<<<< HEAD

=======
     <?php echo $__env->make('front.validation.register_valid', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
>>>>>>> 1875118c55bc7655e627a7db1f18fb597fc662fc
    <?php echo $__env->yieldContent('scripts'); ?>
    <!-- ====================================== End JS files ========================================= -->

</body>

</html>