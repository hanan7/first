<!--//******************************************************************************************************** \\
////////////////////////////////////////// TITLE/////////////////////////////////////////////////// \\
//******************************************************************************************************** \\-->
<?php $__env->startSection('title'); ?>
DOCAAN
<?php $__env->stopSection(); ?>
<!--//******************************************************************************************************** \\
////////////////////////////////////////// style/////////////////////////////////////////////////// \\
//******************************************************************************************************** \\-->
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL('assets/front/css/style.css')); ?>" />
<?php $__env->stopSection(); ?>
<!--//******************************************************************************************************** \\
////////////////////////////////////////// scripts/////////////////////////////////////////////////// \\
//******************************************************************************************************** \\-->
<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(URL('assets/front/js/home-script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<!--//******************************************************************************************************** \\
////////////////////////////////////////// slider/////////////////////////////////////////////////// \\
//******************************************************************************************************** \\-->
<?php $__env->startSection('slider'); ?>
  <div class="slider">
                    <div class="layerslider full_width" style="width:100%; height: 400px;">

                        <!-- - - - - - - - - - - - - - Slide 1 - - - - - - - - - - - - - - - - -->

                        <div class="ls-slide" data-ls="transition2d: 10, 27, 63, 67, 69;">

                            <img class="ls-bg" src="<?php echo e(URL('assets/front/images/slide-2.png')); ?>" alt="">

                            <div class="ls-l layer_1" style="left: 80px; top:128px;" data-ls="offsetxin: -60; durationin: 650; easingin: easeOutBack;"></div>
                            <div class="ls-l layer_2" style="left: 80px; top: 188px;" data-ls="offsetxin: -60; durationin: 650; easingin: easeOutBack; delayin: 150;"></div>
                            <div class="ls-l layer_3" style="left: 80px; top: 252px;" data-ls="offsetxin: -60; durationin: 650; easingin: easeOutBack; delayin: 300;"></div>

                        </div>

                        <!-- - - - - - - - - - - - - - End of slide 1 - - - - - - - - - - - - - - - - -->

                        <!-- - - - - - - - - - - - - - Slide 2 - - - - - - - - - - - - - - - - -->

                        <div class="ls-slide" data-ls="transition2d: 10, 27, 63, 67, 69;">

                            <img class="ls-bg" src="<?php echo e(URL('assets/front/images/slide-1.png')); ?>" alt="">

                            <div class="ls-l layer_5" style="left: 50%; top:114px;" data-ls="offsetxin: -60; durationin: 650; easingin: easeOutBack;">
                            </div>
                            <div class="ls-l layer_6" style="left: 50%; top: 185px;" data-ls="offsetxin: -60; durationin: 650; easingin: easeOutBack; delayin: 150; ">

                            </div>

                        </div>

                        <!-- - - - - - - - - - - - - - End of slide 2 - - - - - - - - - - - - - - - - -->

                    </div>
                </div>
<?php $__env->stopSection(); ?>
<!--//******************************************************************************************************** \\
////////////////////////////////////////// content/////////////////////////////////////////////////// \\
//******************************************************************************************************** \\-->
<?php $__env->startSection('content'); ?>
<section class="features">
        <div class="container-fluid">
            <div class="row">
                <div class="feat">
                    <ul>
                        <li>
                            <i class="fa fa-thumbs-o-up"></i>
                            <span class="caption">عملائنا محط إهتمامنا</span>
                        </li>
                        <li>
                            <i class="fa  fa-paper-plane-o"></i>
                            <span class="caption">شعارنا الخدمة المتميزة</span>
                        </li>
                        <li class="ss">
                            <i class="fa fa-lock"></i>
                            <span class="caption">المصداقية والموثوقية</span>
                        </li>
                        <li>
                            <i class="fa fa-diamond"></i>
                            <span class="caption">الريادة فى الأعمـال</span>
                        </li>
                        <li>
                            <i class="fa  fa-ticket"></i>
                            <span class="caption">الخدمة مجانية لجميع الزائرين </span>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="clear"></div>
    <!--================== Start Vip ==========================-->
    <div class="vip">
        <div class="container-fluid over">
            <div class="row">
                <div class="sec-tit">
                    <i class="fa fa-star" style="float:right;border-left: 1px solid #fff;"></i>
                    <p>دكاكيــن VIP</p>
                    <i class="fa fa-star" style="float: left;border-right: 1px solid #fff;"></i>
                </div>
                <div id="vip-slider" class="carousel slide" id="myCarousel" data-ride="carousel">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-1.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>
                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-3.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>
                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-2.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>
                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-4.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>
                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-5.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>
                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-6.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>

                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-7.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>

                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="doca">
                                <div class="img">
                                    <img src="images/off-c-1.jpg">
                                    <div class="img-over">
                                        <p><a href="docaan.html">دكـــان shop</a></p>

                                        <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                            <span class="fa fa-heart"></span>
                                        </a>
                                        <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                            <span class="fa fa-bell-o"></span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- Controls -->
                    <a class="left carousel-control" href="#vip-slider" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#vip-slider" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>
    <!--===================================== Start Docans(موضه وازياء) ==============================-->
    <div class="docans" id="moda">
        <div class="container-fluid">
            <div class="row">
                <div class="docans-con">
                    <div class="sec-tit">
                        <span class="fa fa-female"></span> موضـة و أزياء
                    </div>
                    <div id="mod" class="carousel slide" data-ride="carousel">
                        <div class="ads">
                            <img src="images/ads-4.jpg">

                        </div>
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/15.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/16.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/17.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/18.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/15.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/16.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/17.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/18.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>

                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#mod" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#mod" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================== Start Docans(إلكترونيات) ==============================-->
    <div class="docans" id="elect">
        <div class="container-fluid">
            <div class="row">
                <div class="docans-con">
                    <div class="sec-tit">
                        <span class="fa fa-desktop"></span> إكسسورات
                    </div>
                    <div id="ele" class="carousel slide" data-ride="carousel">
                        <div class="ads">
                            <img src="images/ads-3.jpg">

                        </div>
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/6.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/8.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/9.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/9.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/5.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/6.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/7.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/8.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>

                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#ele" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#ele" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================== Start Docans(أثاث المنزل) ==============================-->
    <div class="docans" id="furn">
        <div class="container-fluid">
            <div class="row">
                <div class="docans-con">
                    <div class="sec-tit">
                        <span class="fa fa-home"></span> أثاث المنزل
                    </div>
                    <div id="docans-slider" class="carousel slide" data-ride="carousel">
                        <div class="ads">
                            <img src="images/ads.jpg">

                        </div>
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/1.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/2.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/4.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/5.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/2.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/3.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/4.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/5.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>

                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#docans-slider" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#docans-slider" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================== Start Docans(إكسسورات) ==============================-->
    <div class="docans" id="access">
        <div class="container-fluid">
            <div class="row">
                <div class="docans-con">
                    <div class="sec-tit">
                        <span class="fa fa-diamond"></span> إكسسورات
                    </div>
                    <div id="acc" class="carousel slide" data-ride="carousel">
                        <div class="ads">
                            <img src="images/ads-2.jpg">

                        </div>
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/6.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/8.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/9.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/9.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/5.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/6.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/7.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="doca">
                                    <div class="img">
                                        <img src="images/8.jpg">
                                        <div class="img-over">
                                            <a href="docaan.html" data-toggle="tooltip" data-placement="top" title="مشاهدة الدكان"> <span class="fa fa-eye"></span> </a>

                                            <a href="#" data-toggle="tooltip" data-placement="top" title="إضافة إلى المفضلة">
                                                <span class="fa fa-heart"></span>
                                            </a>
                                            <a href="#" data-toggle="tooltip" data-placement="top" title="متابعة الدكان">
                                                <span class="fa fa-bell-o"></span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="con">
                                        <a href="docaan.html"><h1> دكــان Shop</h1></a>
                                        <div class="follow">
                                            <span class="fa fa-users"></span> 150 متابع
                                        </div>
                                        <p>أزيــاء وموضــة</p>

                                        <div class="star">
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#acc" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#acc" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>