 <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
            <thead>
              <tr>
                <th width="10%"> رقم القسم </th>
                <th width="30%"> اسم القسم</th>
                <th class="text-center"> تاريخ الاضافة</th>
                <th class="text-center"> اسم المضيف</th>
                <th class="text-center">العمليات</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach($categories as $cat): ?>
              <tr>
                                            
                <td class="text-center"><?php echo e($cat->id); ?></td>
                <td class="text-center"><?php echo e($cat->cat_trans("ar")->name); ?></td>
                 <td class="text-center"><?php echo e($cat->created_at); ?></td>
                  <td class="text-center"></td>
                <td class="text-center">
                  <a href="<?php echo e(url('categories/update')); ?>"  class="btn green btnedit" data-original="">
                    <li class="fa fa-pencil"> تعديل</li>
                  </a>
                  <a elementId=""   class="btn btn-danger btndelet"  >
                      <li class="fa fa-trash">  مسح</li>
                  </a>
                </td>
               
              </tr>
              <?php endforeach; ?> 
            </tbody>
          </table>