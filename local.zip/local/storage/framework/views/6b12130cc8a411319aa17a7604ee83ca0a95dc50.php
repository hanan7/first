<?php $__env->startSection("title"); ?>
الفنادق
<?php $__env->stopSection(); ?>
<?php $__env->startSection("page-style"); ?>
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>" 
              rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content-title"); ?>
 <h3 class="page-title">الفنادق</h3>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-navigat"); ?>
<ul class="page-breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">الصفحة الرئيسية</a>
    <i class="fa fa-angle-left"></i>
  </li>
  <li>
   <a href="#">الفنادق</a>


 </li>
                         
</ul>
<?php $__env->stopSection(); ?>
                
<?php $__env->startSection('content'); ?>

 <?php if(isset($errors)&&count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; ?>
            </ul>
        </div>
 <?php endif; ?>
 <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('success')); ?> </p>
    
    </div>
 <?php endif; ?>
  <?php if(session()->has('danger')): ?>
    <div class="alert alert-warrning alert-dismissable">
      <button class="close" data-dismiss="alert" area-hidden="true">&times;</button>
      <p><?php echo e(session()->get('danger')); ?> </p>
    
    </div>
  <?php endif; ?> 
  <div class="row">
    <div class="col-md-12">
      <div class="tabbable tabbable-custom tabbable-noborder tabbable-reversed">
        <div class="portlet box green">
                    <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-plus"></i>
                                    تعديل فندق
                                </div>
                            </div>

                    <div  class="portlet-body form">
                       <form method="post" name="settingform" action="<?php echo e(URL('hotels/edit/'.$old->id)); ?>"  id="settingform" class="horizontal-form"  files="true" enctype="multipart/form-data">
                           <input type="hidden"  name="_token" value="<?php echo e(csrf_token()); ?>">
                           
                           <div class="form-body">
                              <h3 class="form-section">اضافة فندق</h3>
                               
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">اسم الفندق</label>
                                        <input type="text" id="hotel_name" name="hotel_name" value="<?php echo e($old->hotel_name); ?>"  class="form-control " >
                                      </div>
                                  </div>
                                </div>  
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">الصورة</label>
                                        <input type="file" id="image" name="image" value="<?php echo e($old->image); ?>" class="form-control " >
                                      </div>
                                  </div>
                                </div>  
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">وصف مختصر</label>
                                        <input type="text" id="short_desc" name="short_desc" value="<?php echo e($old->short_desc); ?>" class="form-control " >
                                      </div>
                                  </div>
                                </div>   
                                <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                        <label class="control-label">الوصف</label>
                                        <textarea id="long_desc" name="long_desc" value="<?php echo e($old->long_desc); ?>" class="form-control " ></textarea>
                                      </div>
                                  </div>
                                </div>                
                            </div>         
                           
                           
                          <div class="form-actions">
                            <div class="col-md-12 text-center" >
                              <button type="submit"  name="submit" class="btn green btn_save">
                              <i class="fa fa-pencil"></i> تعديل</button>
                              <button type="button" class="btn default btn_save">
                              <i class="fa fa-times"></i> الغاء</button> 
                            </div>      
                          </div>
                       </form>
                    </div>
                 </div>
                    
                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>