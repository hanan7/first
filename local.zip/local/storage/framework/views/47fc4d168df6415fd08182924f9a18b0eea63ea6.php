<header>
        <div class="container-fluid">
            <div class="row">
                <div class="top-header">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xm-12">
                        <div class="scoial">
                            <a href="<?php echo e($sections->facebook); ?>">
                                <span class="fa fa-facebook"></span>
                            </a>
                            <a href="<?php echo e($sections->twitter); ?>">
                                <span class="fa fa-twitter"></span>
                            </a>

                            <a href="<?php echo e($sections->googlePlus); ?>">
                                <span class="fa fa-google-plus"></span>
                            </a>
                            <a href="<?php echo e($sections->linkedIn); ?>">
                                <span class="fa fa-linkedin"></span>
                            </a>
                            <a href="<?php echo e($sections->instagram); ?>">
                                <span class="fa fa-instagram"></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xm-12">
                        <div class="top-contact">
                            <p>
                                <i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e($sections->email); ?>

                            </p>
                            <p>
                                <i class="fa fa-phone" aria-hidden="true"></i><?php echo e($sections->phone); ?>


                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="menu">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu" aria- expanded="false">
                            <span class="glyphicon glyphicon-align-justify"></span>
                        </button>
                        <a class="navbar-brand" href="">
                            <img src="<?php echo e(URL('assets/front/images/logo-w.png')); ?>">
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="menu">
                        <nav class="navbar-nav  navbar-left">
                            <li class="active">
                                <a href="<?php echo e(url('home/index')); ?>" class="active">
                                    الرئيسية
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('home/about')); ?>">
                                    عن الشركة
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('trip/trips')); ?>">
                                    رحلات سياحية
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('omra/all')); ?>">
                                الحج والعمرة
                                </a>
                            </li>
                            
                            <li>
                                <a href="<?php echo e(url('hotel/hotels')); ?>">
                                    الفنادق
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('home/plans')); ?>">
                                   حجز طيران
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('home/lemo')); ?>">
                                    ليموزين
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('home/contact')); ?>">
                                    تواصل معنا
                                </a>
                            </li>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
</header>