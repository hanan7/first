    <div class="page-sidebar-wrapper">
                <div class="page-sidebar navbar-collapse collapse">
                    <ul class="page-sidebar-menu  page-header-fixed page-sidebar-menu-hover-submenu  page-sidebar-menu-compact" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                        <li class="nav-item start">
                            <a href="<?php echo e(URL('admin')); ?>" class="nav-link ">
                                <i class="icon-home"></i>
                                <span class="title">الرئيسية</span>
                               
                                <span class="arrow"></span>
                            </a>
                            
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('settings/general-settings')); ?>" class="nav-link">
                            
                               <i class="icon-settings"></i>
                                <span class="title">الاعدادات العامة</span>
                                <span class="arrow"></span>
                            </a>
                           
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('trips/all-trips')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">الرحلات</span>
                            </a>
                        </li>

                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('hajj/all-hajj')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">رحلات الحج والعمرة</span>
                            </a>
                        </li> 
                        
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('hotels/all-hotels')); ?>"  class="nav-link nav-toggle">
                                <i class="icon-bulb"></i>
                                <span class="title">الفنادق</span>
                                <span class="arrow"></span>
                            </a>
                        </li>
                        <li class="nav-item  ">
                            <a href="#" class="nav-link nav-toggle">
                                <i class="icon-briefcase"></i>
                                <span class="title">الحجوزات</span>
                                <span class="arrow"></span>
                            </a>
                             <ul class="sub-menu">
                                <li class="nav-item ">
                                    <a href="<?php echo e(URL('reserve/all-lemo')); ?>" class="nav-link ">
                                        <span class="title ">حجز الليموزين</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a href="<?php echo e(URL('reserve/all-plans')); ?>" class="nav-link ">
                                        <span class="title ">حجز طائرة</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a href="<?php echo e(URL('reserve/all-reserve')); ?>" class="nav-link ">
                                        <span class="title ">حجز رحلة</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                     
               
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
    </div>