    <div class="page-sidebar-wrapper">
                <div class="page-sidebar navbar-collapse collapse">
                    <ul class="page-sidebar-menu  page-header-fixed page-sidebar-menu-hover-submenu  page-sidebar-menu-compact" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200"> 
                        <li class="nav-item start">
                            <a href="<?php echo e(URL('admin')); ?>" class="nav-link ">
                                <i class="icon-home"></i>
                                <span class="title">الرئيسية</span>
                               
                                <span class="arrow"></span>
                            </a>
                            
                        </li>
                        <?php if(Auth::guard('admins')->user()->flag==0 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('settings/general-settings')); ?>" class="nav-link">
                            
                               <i class="icon-settings"></i>
                                <span class="title">الاعدادات العامة</span>
                                <span class="arrow"></span>
                            </a>
                           
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('owners/all-owners')); ?>" class="nav-link">
                            
                               <i class="icon-users"></i>
                                <span class="title">المساهمين</span>
                                <span class="arrow"></span>
                            </a>
                           
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('seeds/all-seeds')); ?>" class="nav-link">
                            
                               <i class="icon-layers"></i>
                                <span class="title">الأصول</span>
                                <span class="arrow"></span>
                            </a>
                           
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1 || Auth::guard('admins')->user()->flag==3 || Auth::guard('admins')->user()->flag==2 || Auth::guard('admins')->user()->flag==4): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('products/all-products')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">البضائع</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1  ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('stores/all-stores')); ?>" class="nav-link nav-toggle">
                                <i class="icon-home"></i>
                                <span class="title">المخازن</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('delegates/all-delegates')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title"> الوكلاء الرئيسين</span>
                            </a>
                        </li>
                        <?php endif; ?>

                         <?php if(Auth::guard('admins')->user()->flag==0): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('subDelegates/all-delegates')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title"> الوكلاء الفرعيين</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0  ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('agents/all-agents')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">العملاء</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        
                        <?php if(Auth::guard('admins')->user()->flag==0  ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('suppliers/all-suppliers')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">الموردين</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==0 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('traders/all-traders')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">التجار</span>
                            </a>
                        </li> 
                        <?php endif; ?>   
                        
                        <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==2  || Auth::guard('admins')->user()->flag==4 || Auth::guard('admins')->user()->flag==3): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('orders/all-orders')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">الطلبيات</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==3  ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('agents/all-places')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">طلبات المعاينة</span>
                            </a>
                        </li>

`                       <?php endif; ?>

                        <?php if(Auth::guard('admins')->user()->flag==2 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('traders/all-debt')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">المديونات</span>
                            </a>
                        </li> 
                        <?php endif; ?>  

                        <?php if(Auth::guard('admins')->user()->flag==2 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('traders/points')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">النقاط</span>
                            </a>
                        </li> 
                        <?php endif; ?>  
                         <?php if(Auth::guard('admins')->user()->flag==3 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('agents/points')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">النقاط</span>
                            </a>
                        </li> 
                        <?php endif; ?>  
                        <?php if(Auth::guard('admins')->user()->flag==4 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('delegates/points')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">النقاط</span>
                            </a>
                        </li> 
                        <?php endif; ?>  

                        <?php if(Auth::guard('admins')->user()->flag==4 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('delegates/custody')); ?>" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">العهدة</span>
                            </a>
                        </li> 
                        <?php endif; ?>  

                        
                        <li class="nav-item  ">
                            <a href="#" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">الرسائل</span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item ">
                                    <a href="<?php echo e(URL('msgs/admin-msgs')); ?>" class="nav-link ">
                                        <span class="title ">رسائل الاعضاء</span>

                                    </a>
                                </li>
                            <?php if(Auth::guard('admins')->user()->flag==0 || Auth::guard('admins')->user()->flag==1): ?>
                                <li class="nav-item ">
                                    <a href="<?php echo e(URL('msgs/all-msgs')); ?>" class="nav-link ">

                                        <span class="title ">رسائل الزوار</span>
                                    </a>
                                </li>
                            <?php endif; ?>    
                            </ul>
                        </li> 
                      

                        <?php if(Auth::guard('admins')->user()->flag==0 ): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('employees/all-employees')); ?>" class="nav-link nav-toggle">
                                <i class="icon-users"></i>
                                <span class="title">الموظفين</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admins')->user()->flag==0): ?>
                        <li class="nav-item  ">
                            <a href="<?php echo e(URL('users/all')); ?>" class="nav-link nav-toggle">
                                <i class="icon-users"></i>
                                <span class="title">المستخدمين</span>
                            </a>
                        </li>
                        <?php endif; ?>
                       
                     
                     
                     
               
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
    </div>