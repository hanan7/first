<div id="tooplate_cr_wrapper">
    <div id="tooplate_cr">
        
      <a href="#">  Copyright © 2016</a><br /><a href="#">جميع الحقوق محفوظه:</a>   <a href="">-شركه ذكاء للبرمجيات</a>
        
    </div> <!-- end of footer wrapper -->
</div> <!-- end of footer -->
